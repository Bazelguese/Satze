# SATZE — Campaign Mode: Cursor Implementation Guide

> **Context:** SATZE is a 1v1 tactical card game built with Electron + React. The core game
> logic has already been extracted into a pure JS module (shared with PvP). This guide
> instructs Cursor to build the Campaign Mode as a self-contained `/campaign` folder inside
> the existing project, importing that shared logic module.
>
> **Reference implementation:** Figli dell'Orizzonte (first campaign). All systems must be
> generic/extensible, with this army as the concrete example.

---

## 1. Architecture & Folder Structure

Add the following structure to the existing project. Do **not** modify `/pvp` or the shared
game logic module — only import from it.

```
/src
  /game-logic/          ← existing shared module (DO NOT MODIFY)
  /pvp/                 ← existing PvP UI (DO NOT MODIFY)
  /campaign/
    index.jsx           ← campaign entry point / router
    CampaignShell.jsx   ← outer shell: war map, pressure bars, current state
    /war-map/
      WarMap.jsx        ← faglia list, pressure bars, mission selection UI
      FagliaCard.jsx    ← single faglia component
    /mission/
      MissionSetup.jsx  ← pre-mission briefing (type, modifiers, enemy deck)
      MissionBattle.jsx ← wraps the shared game-logic battle, applies modifiers
      MissionResult.jsx ← outcome screen: rewards, narrative trigger check
    /gestional/
      GestionalSegment.jsx ← deck management + narrative event display
      Warehouse.jsx        ← card pool available to add to deck
      NarrativeEvent.jsx   ← Persona-style text + moral choice UI
    /state/
      campaignState.js     ← all campaign state: run, faglie, deck, warehouse, narrative
      campaignReducer.js   ← pure reducer for all state transitions
      useCampaign.js       ← React hook wrapping state + dispatch
    /data/
      constants.js         ← all configurable placeholder values
      armies/
        figliDellOrizzonte.js   ← army definition: cards, bonus, lore, campaign config
      missions/
        missionTemplates.js     ← base mission type definitions
      narrative/
        figliNarrativeEvents.js ← all narrative events for this campaign
```

---

## 2. Configurable Constants (`/data/constants.js`)

These values are **design placeholders** — implement them as named exports so they can be
changed in one place without touching logic.

```js
// /src/campaign/data/constants.js

export const CAMPAIGN_CONSTANTS = {
  // War calendar
  FAGLIE_PER_DAY: 2,                   // how many faglie open each in-game day
  FAGLIA_GROWTH_PER_IGNORE: 15,        // pressure added per ignored day (out of 100)
  MANDATORY_DEFENSE_THRESHOLD: 100,    // pressure at which mandatory defense triggers
  FRONT_ADVANCE_ON_DEFENSE_LOSS: 30,   // HQ damage when mandatory defense is lost

  // Campaign failure
  HQ_MAX_INTEGRITY: 100,               // campaign fails when this reaches 0
  HQ_DAMAGE_PER_FRONT_ADVANCE: 25,     // HQ damage per enemy front advance step

  // Deck & warehouse
  STARTING_DECK_SIZE: 3,               // protagonist + 2 chosen cards
  STARTING_POOL_LEAGUE_MAX: 4,         // max league tier available at campaign start
  HAND_SIZE: 5,                        // cards drawn per battle (same as PvP)

  // Missions per run (undecided — placeholder range)
  ESTIMATED_MISSIONS_PER_RUN_MIN: 12,
  ESTIMATED_MISSIONS_PER_RUN_MAX: 20,

  // Defeat consequences (undecided — current: reduced gestional segment)
  // Additional consequences to be defined. Add fields here when decided.
  DEFEAT_REDUCES_GESTIONAL: true,
  DEFEAT_GESTIONAL_REDUCTION_FACTOR: 0.5, // half the normal gestional time/options

  // Enemy AI FC budget per mission type (placeholder)
  ENEMY_FC_BY_MISSION: {
    assalto: 18,
    difesa: 18,
    dominio: 16,
    annichilimento: 20,
  },
};
```

---

## 3. Core Data Models

### 3.1 Campaign Run State

```js
// Shape of the full campaign state (managed by campaignReducer.js)
const INITIAL_CAMPAIGN_STATE = {
  // Identity
  armyId: null,             // e.g. "figliDellOrizzonte"
  campaignId: null,         // e.g. "campaign_fdh_01"

  // War map
  currentDay: 1,
  faglie: [],               // array of FagliaState objects (see §3.2)
  hqIntegrity: 100,         // drops when fronts advance; 0 = campaign over

  // Deck & warehouse
  activeDeck: [],           // array of card IDs currently in the battle deck
  warehouse: [],            // array of card IDs available but not in deck
  protagonist: null,        // card ID — always in deck, cannot be removed

  // Narrative
  pendingNarrativeEvents: [], // events to show in next gestional segment
  completedEvents: [],        // event IDs already shown (for meta-narrative tracking)
  moralChoices: {},           // eventId → choiceKey made

  // Battle tracking
  lastBattleResult: null,     // "victory" | "defeat" | null
  cardsPlayedThisRun: 0,
  missionsCompleted: 0,
  missionHistory: [],         // { type, result, day, reward } objects

  // Meta-narrative
  anomalyTriggered: false,    // true when the hidden meta-narrative moment fires
};
```

### 3.2 Faglia State

```js
// Shape of a single faglia
const FAGLIA_TEMPLATE = {
  id: "faglia_uuid",
  enemyArmyId: "kethran",       // which enemy army this faglia belongs to
  pressure: 0,                   // 0–100; at 100 → mandatory defense triggers
  isMandatory: false,            // true when pressure hit 100
  availableMissions: [],         // MissionInstance objects
  isResolved: false,             // true when closed by player victory
};
```

### 3.3 Mission Instance

```js
const MISSION_INSTANCE = {
  id: "mission_uuid",
  fagliaId: "faglia_uuid",
  type: "assalto",              // "assalto" | "difesa" | "dominio" | "annichilimento"
  subType: null,                // null | "assalto+annichilimento" | "difesa+dominio"
  isSpecial: false,             // true if combined type
  isMandatory: false,
  enemyDeck: [],                // array of card objects (enemy hand for this fight)
  battlefieldId: null,          // which campo di battaglia is used
  modifiers: {
    playerGoesFirst: true,      // assalto=true, difesa=false, others=determined randomly
    winConditionOverride: null, // annichilimento overrides normal win to "0 PV only"
    additionalObjective: null,  // dominio: { fieldToCapture: "battlefieldId" }
  },
  rewardPool: [],               // card IDs that can be rewarded
  narrativeTrigger: null,       // narrative event ID to fire if this mission is completed
};
```

---

## 4. Mission Type System (`/data/missions/missionTemplates.js`)

```js
export const MISSION_TYPES = {
  assalto: {
    label: "Assalto",
    description: "Il giocatore ha iniziativa nei primi due turni.",
    playerGoesFirst: true,
    winCondition: "standard",   // conquest (T1-4) or supremacy (T5+) or annihilation
    rewardProfile: "offensive", // cards with Imboscata, Conquista, Gloria triggers
  },
  difesa: {
    label: "Difesa",
    description: "Il nemico ha iniziativa nei primi due turni.",
    playerGoesFirst: false,
    winCondition: "standard",
    rewardProfile: "defensive", // cards with Intervento, Vendetta, Rimonta triggers
  },
  dominio: {
    label: "Dominio",
    description: "Vittoria normale + conquista obbligatoria di un campo specifico.",
    playerGoesFirst: null,      // determined per-instance
    winCondition: "standard+field", // must also capture the designated battlefield
    rewardProfile: "field",     // cards tied to the captured battlefield + field modifiers
  },
  annichilimento: {
    label: "Annichilimento",
    description: "Vittoria solo per annientamento (avversario a 0 PV).",
    playerGoesFirst: null,
    winCondition: "annihilation_only", // standard conquest/supremacy NOT valid
    rewardProfile: "rare",      // rare cards or Lega 5; possible narrative cost
  },
};

// Special (combined) mission types — appear only on grown faglie or key narrative moments
export const SPECIAL_MISSION_TYPES = {
  "assalto+annichilimento": {
    label: "Assalto Totale",
    base: ["assalto", "annichilimento"],
    playerGoesFirst: true,
    winCondition: "annihilation_only",
    rewardProfile: "offensive+rare",
    appearsWhen: "faglia_grown_aggressive", // grown faglia from an aggressive enemy
  },
  "difesa+dominio": {
    label: "Resistenza Territoriale",
    base: ["difesa", "dominio"],
    playerGoesFirst: false,
    winCondition: "standard+field",
    rewardProfile: "defensive+field",
    appearsWhen: "mandatory_defense_advanced_front",
  },
};
```

---

## 5. Faglia & War Map System

### 5.1 Faglia Logic (`campaignReducer.js`)

Implement the following state transitions as pure reducer cases:

```js
// IGNORE_FAGLIA: player did not address this faglia today
case "IGNORE_FAGLIA": {
  const { fagliaId } = action;
  return updateFaglia(state, fagliaId, faglia => ({
    ...faglia,
    pressure: Math.min(100, faglia.pressure + CAMPAIGN_CONSTANTS.FAGLIA_GROWTH_PER_IGNORE),
    isMandatory: faglia.pressure + CAMPAIGN_CONSTANTS.FAGLIA_GROWTH_PER_IGNORE >= 100,
  }));
}

// RESOLVE_FAGLIA: player won a mission from this faglia
case "RESOLVE_FAGLIA": {
  const { fagliaId, reward } = action;
  return {
    ...updateFaglia(state, fagliaId, f => ({ ...f, pressure: 0, isResolved: true })),
    warehouse: [...state.warehouse, ...reward.cardIds],
    pendingNarrativeEvents: maybeAddNarrativeEvent(state, reward.narrativeTrigger),
  };
}

// MANDATORY_DEFENSE_LOST: player lost the mandatory defense mission
case "MANDATORY_DEFENSE_LOST": {
  const newIntegrity = state.hqIntegrity - CAMPAIGN_CONSTANTS.HQ_DAMAGE_PER_FRONT_ADVANCE;
  return {
    ...state,
    hqIntegrity: newIntegrity,
    lastBattleResult: "defeat",
    // Additional defeat consequences: add here when decided
  };
}

// CAMPAIGN_FAILED: HQ integrity reached 0
case "CAMPAIGN_FAILED": {
  return { ...state, status: "failed", failReason: "hq_destroyed" };
}
```

### 5.2 WarMap UI (`WarMap.jsx`)

The WarMap component shows:
- One pressure bar per active enemy faction
- Visual indicator when a faglia is mandatory (pulsing red border)
- Available missions per faglia (up to 2)
- HQ integrity indicator (minimal — a single bar or integrity value)

The component should **not** contain logic — it only reads state via `useCampaign()` and
dispatches events. Keep it purely presentational.

**Key UI rules:**
- Pressure bars are always visible, readable at a glance
- Mandatory missions must be visually unmistakable (cannot be missed)
- The HQ integrity bar is secondary — present but not dominant
- This is a placeholder UI: do not over-engineer the visual representation now.
  A list of faction rows with progress bars is sufficient for this stage.

---

## 6. Deck & Warehouse System

### 6.1 Rules to Implement

- The **active deck** starts at 3 cards: protagonist (fixed) + 2 chosen by the player
- Cards rewarded from missions go to the **warehouse**, not the active deck
- The player can only modify the deck during **gestional segments**
- Adding a card from the warehouse means removing one from the active deck
  (the protagonist card cannot be removed)
- The deck must respect the standard SATZE rules: 10 cards max, 30 Lega max
  (these limits apply as the deck grows through the campaign)
- League 5 cards are **not** in the starting pool — only obtainable as mission rewards
  (Annichilimento or special missions)

### 6.2 Warehouse Component (`Warehouse.jsx`)

Display:
- Cards in the warehouse grouped by Lega
- Each card shows: name, POT, DAN, Lega, trigger, power
- "Add to deck" button — disabled if deck is at max size or Lega budget is exceeded
- Current deck below (or in a side panel), showing the same card info
- Remove button on deck cards (disabled for protagonist)
- Real-time Lega counter: `{totalLeague} / 30`

---

## 7. Gestional Segment System

### 7.1 Trigger Rules

The gestional segment fires after every mission. Its **depth** depends on the outcome:

| Trigger | Segment type | What's available |
|---|---|---|
| Victory (important mission or mid-boss) | Full | Deck edit + all narrative events + war map review |
| Narrative event trigger | Full or partial | Moral choice + optional deck edit |
| Defeat | Reduced | Deck edit with fewer options; narrative events limited |
| Lost mandatory defense | Minimal / none | No deck edit; war map only; pressure |

Implement `getSegmentDepth(result, isMandatory)` as a pure function returning
`"full" | "reduced" | "minimal"`.

### 7.2 GestionalSegment.jsx

This is a screen-level component that:
1. Receives `segmentDepth` as a prop
2. Shows/hides sections based on depth:
   - `"full"` → Warehouse + NarrativeEvents + WarMapReview
   - `"reduced"` → Warehouse (limited) + WarMapReview only
   - `"minimal"` → WarMapReview only
3. Dispatches `END_GESTIONAL` when the player confirms they're done

---

## 8. Narrative Event System

### 8.1 NarrativeEvent Format

```js
// Each event in figliNarrativeEvents.js follows this shape:
const NARRATIVE_EVENT = {
  id: "fdh_event_01",
  title: "Il Canto si fa più forte",
  body: `
    Testo dell'evento narrativo. Breve, mai più di 3-4 paragrafi.
    Stile: Persona — contestuale, netto, senza voce narrante invadente.
  `,
  triggeredBy: "mission_victory",   // or "mission_defeat" | "day_N" | "mission_id"
  choices: [
    {
      key: "choice_mercy",
      label: "Mostrare misericordia",
      consequence: {
        type: "faglia_pressure_modifier",
        fagliaArmyId: "kethran",
        delta: -10,        // reduces pressure on Kethran's faglia
      },
    },
    {
      key: "choice_advance",
      label: "Avanzare senza sosta",
      consequence: {
        type: "faglia_pressure_modifier",
        fagliaArmyId: "kethran",
        delta: +10,
      },
    },
  ],
  isMetaNarrative: false,   // true for the anomaly moments (see §8.2)
};
```

### 8.2 Meta-Narrative Anomaly (Figli dell'Orizzonte specific)

One event in the Figli campaign must be flagged `isMetaNarrative: true`. This is the moment
where the player begins to sense that the Canto della Nebula is not what it seems.

**Implementation rules for this event:**
- Only fires in the late campaign (after mission N — leave N as `ANOMALY_TRIGGER_MISSION`
  constant, value TBD)
- The UI renders it differently: no background music transition, text appears without fade,
  the choice labels are slightly wrong (as if something is interfering with the text)
- Set `state.anomalyTriggered = true` when it fires
- Do not explain it. Do not add a tooltip. It should feel like a glitch in the game itself.

```js
// In constants.js, add:
ANOMALY_TRIGGER_MISSION: null,  // placeholder — set when narrative is finalized
```

---

## 9. Reference Implementation — Figli dell'Orizzonte

### 9.1 Army Definition (`/data/armies/figliDellOrizzonte.js`)

```js
export const FIGLI_DELL_ORIZZONTE = {
  id: "figliDellOrizzonte",
  name: "Figli dell'Orizzonte",
  color: "#7c3aed",       // violet — adapt to match existing army theme
  hqName: "Sistema di Vaelith",

  // Campaign config
  campaignId: "campaign_fdh_01",
  protagonist: 101,       // Sorethal, il Primo Ancorante — fixed, cannot be removed

  // Starting pool for the 2 player-chosen cards (Lega 2–4 only)
  startingPool: [102, 103, 104, 105, 106, 107, 108, 109, 110, 112, 113, 114, 115],
  // Note: 111 (L'Eco del Primo Sole, Lega 5) is NOT in starting pool

  // Army bonus
  bonus: {
    description: "-5 VA nemico (min 6)",
    condition: "always",  // activates when 2+ Figli cards are in hand
    apply: (enemyVA) => Math.max(6, enemyVA - 5),
  },

  // Full card roster
  cards: [
    { id: 101, name: "Sorethal, il Primo Ancorante",  league: 5, pot: 6, dan: 4,  trigger: "Sempre",         power: "-8 VA nem." },
    { id: 102, name: "Tessitrice della Trama",         league: 4, pot: 5, dan: 3,  trigger: "Conquista",       power: "Cura 2" },
    { id: 103, name: "Portatore della Domanda",        league: 4, pot: 4, dan: 4,  trigger: "Resa dei conti",  power: "-4 VA nem." },
    { id: 104, name: "Cartografo del Vuoto",           league: 3, pot: 3, dan: 3,  trigger: "Imboscata",       power: "+2 FC" },
    { id: 105, name: "Richiamante dell'Ordine",        league: 3, pot: 4, dan: 2,  trigger: "Intervento",      power: "+2 POT" },
    { id: 106, name: "Condensato per la Guerra",       league: 3, pot: 3, dan: 3,  trigger: "Imboscata",       power: "3 DAN dir." },
    { id: 107, name: "Eco Svanente",                   league: 2, pot: 3, dan: 1,  trigger: "Sempre",          power: "Blocca Bonus" },
    { id: 108, name: "Leggero Richiamato",             league: 2, pot: 2, dan: 2,  trigger: "Ultimo desiderio",power: "2 DAN dir." },
    { id: 109, name: "Naela, la Prima Sognatrice",     league: 2, pot: 3, dan: 1,  trigger: "Vendetta",        power: "+3 POT" },
    { id: 110, name: "Ashara, la Volontaria",          league: 2, pot: 5, dan: 1,  trigger: "Conquista",       power: "-2 PV (a te)" },
    { id: 111, name: "L'Eco del Primo Sole",           league: 5, pot: 5, dan: 6,  trigger: "Gloria",          power: "+6 VA" },
    { id: 112, name: "Serath, Che Mangia il Dopo",     league: 4, pot: 6, dan: 3,  trigger: "Resa dei conti",  power: "+2 DAN" },
    { id: 113, name: "L'Ultimo Specchio di Oris",      league: 3, pot: 1, dan: 4,  trigger: "Sempre",          power: "Copia POT nem." },
    { id: 114, name: "Il Portatore della Campana",     league: 3, pot: 4, dan: 3,  trigger: "Gloria",          power: "+1 POT, +1 DAN" },
    { id: 115, name: "Vethan, Guerriero per un Giorno",league: 2, pot: 3, dan: 1,  trigger: "Sempre",          power: "-1 DAN nem. (min 3)" },
  ],
};
```

### 9.2 Enemy Factions for Figli Campaign

The Figli campaign has multiple enemy factions whose faglie open throughout the run.
Exact enemy rosters are TBD — use placeholder enemy decks for now. Define them as:

```js
export const FIGLI_ENEMY_FACTIONS = [
  {
    id: "enemy_faction_1",
    name: "placeholder — define during narrative design",
    aggressiveProfile: true,   // grows faglie faster, uses Assalto missions
    placeholderDeck: [],       // fill with enemy cards when narrative is finalized
  },
  // Add more factions as campaign is designed
];
```

---

## 10. Battle Integration

### 10.1 How Campaign Battles Connect to Shared Game Logic

The `MissionBattle.jsx` component wraps the existing shared battle module. Before starting,
it applies mission modifiers:

```js
// MissionBattle.jsx — setup before delegating to shared battle
function prepareBattleConfig(mission, campaignState, armyDef) {
  return {
    playerDeck: campaignState.activeDeck,
    enemyDeck: mission.enemyDeck,
    playerFC: 18,           // standard; may be modified by future campaign mechanics
    enemyFC: CAMPAIGN_CONSTANTS.ENEMY_FC_BY_MISSION[mission.type],
    playerGoesFirst: mission.modifiers.playerGoesFirst,
    winConditionOverride: mission.modifiers.winConditionOverride,
    additionalObjective: mission.modifiers.additionalObjective,
    armyBonus: armyDef.bonus,
  };
}
```

The shared battle module returns a result object. `MissionBattle.jsx` passes it to
`MissionResult.jsx`, which dispatches the appropriate campaign state action
(`RESOLVE_FAGLIA`, `MANDATORY_DEFENSE_LOST`, etc.).

### 10.2 Win Condition Overrides

The shared game logic module must support a `winConditionOverride` parameter.
If `"annihilation_only"` is passed:
- Territory conquest (3 fields) does NOT trigger victory
- Supremacy (more PV at end of turn 5+) does NOT trigger victory
- Only reaching 0 enemy PV wins the battle

**If the shared module does not currently support this override, implement it there
as a configuration option before building campaign mission flow.**

---

## 11. State Management Pattern

Use a single `useCampaign()` hook that encapsulates all campaign state.

```js
// useCampaign.js
import { useReducer } from "react";
import { campaignReducer, INITIAL_CAMPAIGN_STATE } from "./campaignReducer";

export function useCampaign() {
  const [state, dispatch] = useReducer(campaignReducer, INITIAL_CAMPAIGN_STATE);

  return {
    state,
    // War map actions
    ignoreFaglia: (fagliaId) => dispatch({ type: "IGNORE_FAGLIA", fagliaId }),
    selectMission: (missionId) => dispatch({ type: "SELECT_MISSION", missionId }),
    resolveFaglia: (fagliaId, reward) => dispatch({ type: "RESOLVE_FAGLIA", fagliaId, reward }),
    mandatoryDefenseLost: () => dispatch({ type: "MANDATORY_DEFENSE_LOST" }),
    // Gestional actions
    addCardToDeck: (cardId) => dispatch({ type: "ADD_TO_DECK", cardId }),
    removeCardFromDeck: (cardId) => dispatch({ type: "REMOVE_FROM_DECK", cardId }),
    completeNarrativeEvent: (eventId, choiceKey) =>
      dispatch({ type: "COMPLETE_NARRATIVE_EVENT", eventId, choiceKey }),
    endGestional: () => dispatch({ type: "END_GESTIONAL" }),
    // Campaign lifecycle
    startCampaign: (armyId) => dispatch({ type: "START_CAMPAIGN", armyId }),
    endCampaign: (result) => dispatch({ type: "END_CAMPAIGN", result }),
  };
}
```

Pass `useCampaign()` only to `CampaignShell.jsx` — all children receive only what they need
via props. Do not use global context for campaign state at this stage.

---

## 12. Campaign Entry Point (`index.jsx`)

```jsx
// /src/campaign/index.jsx
// This is the route/screen that Electron loads for campaign mode.
// It replaces the main screen when the player selects "Campaign" from the main menu.

import React from "react";
import CampaignShell from "./CampaignShell";
import { FIGLI_DELL_ORIZZONTE } from "./data/armies/figliDellOrizzonte";

export default function CampaignMode() {
  // For now, hardcode Figli dell'Orizzonte as the only available campaign
  return <CampaignShell armyDef={FIGLI_DELL_ORIZZONTE} />;
}
```

---

## 13. What NOT to Build Yet

The following are documented but explicitly **out of scope** for this implementation phase:

- Roguelike mode — post-launch
- Kethran campaign — second campaign, to be built after Figli is complete
- Alliance system (dynamic enemy coalitions) — logic base is defined but not implementing now
- Battlefield pool expansion system — define the hook, leave logic as TODO
- Mobile layout — PC only for now
- Persistence / save system — implement state in memory first; add save/load after the
  system works end-to-end
- Exact narrative events content — leave `figliNarrativeEvents.js` with placeholder
  events; fill in during narrative writing phase

---

## 14. Implementation Order (Suggested)

Build in this sequence to always have something testable:

1. **Data layer** — `constants.js`, `figliDellOrizzonte.js`, `missionTemplates.js`
2. **State layer** — `campaignState.js`, `campaignReducer.js`, `useCampaign.js`
3. **WarMap UI** — `WarMap.jsx` + `FagliaCard.jsx` with mock faglie
4. **Mission flow** — `MissionSetup.jsx` → `MissionBattle.jsx` (with shared module) → `MissionResult.jsx`
5. **Gestional segment** — `GestionalSegment.jsx` + `Warehouse.jsx`
6. **Narrative events** — `NarrativeEvent.jsx` + placeholder events
7. **Campaign shell** — `CampaignShell.jsx` wiring everything together
8. **Win/loss conditions** — campaign victory (enemy HQ reached) and failure (HQ destroyed)
9. **Meta-narrative anomaly event** — last, after narrative content is written

---

*SATZE — Campaign Mode Cursor Guide — March 2026*
*Language: English (for Cursor prompt effectiveness)*
*Source documents: CAMPAIGN_MODE_SATZE.docx, REGOLE.md, CARTE_FIGLI_DELL_ORIZZONTE.md, LORE_FIGLI_DELL_ORIZZONTE.md*
