import { useState, useEffect } from "react";

// ─── FONT INJECTION ──────────────────────────────────────────────────────────
const injectFonts = () => {
  if (document.getElementById("satze-fonts")) return;
  const link = document.createElement("link");
  link.id = "satze-fonts";
  link.rel = "stylesheet";
  link.href = "https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap";
  document.head.appendChild(link);
};

// ─── DESIGN TOKENS ───────────────────────────────────────────────────────────
const C = {
  bg:          "#06080e",
  panelBg:     "#0b0e17",
  panelBg2:    "#0f1220",
  border:      "#1a2030",
  violet:      "#6d28d9",
  violetLit:   "#8b5cf6",
  violetDim:   "#2e1a5e",
  amber:       "#d97706",
  amberLit:    "#fbbf24",
  red:         "#dc2626",
  redLit:      "#f87171",
  green:       "#15803d",
  greenLit:    "#4ade80",
  textPri:     "#dde4f0",
  textSec:     "#7a8aaa",
  textMuted:   "#3d4a60",
  mono:        "#c8d8f0",
};

const FONTS = {
  ui:   `'Rajdhani', 'Segoe UI', system-ui, sans-serif`,
  mono: `'Share Tech Mono', 'Courier New', monospace`,
};

// ─── DATA ────────────────────────────────────────────────────────────────────
const FIGLI_CARDS = [
  { id: 101, name: "Sorethal, il Primo Ancorante",    league: 5, pot: 6, dan: 4, trigger: "Sempre",          power: "-8 VA nem.",          protagonist: true },
  { id: 102, name: "Tessitrice della Trama",           league: 4, pot: 5, dan: 3, trigger: "Conquista",        power: "Cura 2" },
  { id: 103, name: "Portatore della Domanda",          league: 4, pot: 4, dan: 4, trigger: "Resa dei conti",   power: "-4 VA nem." },
  { id: 104, name: "Cartografo del Vuoto",             league: 3, pot: 3, dan: 3, trigger: "Imboscata",        power: "+2 FC" },
  { id: 105, name: "Richiamante dell'Ordine",          league: 3, pot: 4, dan: 2, trigger: "Intervento",       power: "+2 POT" },
  { id: 106, name: "Condensato per la Guerra",         league: 3, pot: 3, dan: 3, trigger: "Imboscata",        power: "3 DAN dir." },
  { id: 107, name: "Eco Svanente",                     league: 2, pot: 3, dan: 1, trigger: "Sempre",           power: "Blocca Bonus" },
  { id: 108, name: "Leggero Richiamato",               league: 2, pot: 2, dan: 2, trigger: "Ultimo desiderio", power: "2 DAN dir." },
  { id: 109, name: "Naela, la Prima Sognatrice",       league: 2, pot: 3, dan: 1, trigger: "Vendetta",         power: "+3 POT" },
  { id: 110, name: "Ashara, la Volontaria",            league: 2, pot: 5, dan: 1, trigger: "Conquista",        power: "-2 PV (a te)" },
  { id: 111, name: "L'Eco del Primo Sole",             league: 5, pot: 5, dan: 6, trigger: "Gloria",           power: "+6 VA",               leagueGated: true },
  { id: 112, name: "Serath, Che Mangia il Dopo",       league: 4, pot: 6, dan: 3, trigger: "Resa dei conti",   power: "+2 DAN" },
  { id: 113, name: "L'Ultimo Specchio di Oris",        league: 3, pot: 1, dan: 4, trigger: "Sempre",           power: "Copia POT nem." },
  { id: 114, name: "Il Portatore della Campana",       league: 3, pot: 4, dan: 3, trigger: "Gloria",           power: "+1 POT, +1 DAN" },
  { id: 115, name: "Vethan, Guerriero per un Giorno",  league: 2, pot: 3, dan: 1, trigger: "Sempre",           power: "-1 DAN nem. (min 3)" },
];

const INITIAL_DECK      = [101, 104, 109];
const INITIAL_WAREHOUSE = [102, 103, 105, 106, 107, 108, 110, 112, 113, 114, 115];

const INITIAL_FAGLIE = [
  { id: "f1", enemyName: "Orathai",     pressure: 0,  isMandatory: false,
    mission: { id: "m1", type: "assalto",         label: "Assalto",         difficulty: 0.65, rewardPool: [106, 114] } },
  { id: "f2", enemyName: "Kethran",     pressure: 30, isMandatory: false,
    mission: { id: "m3", type: "difesa",           label: "Difesa",           difficulty: 0.50, rewardPool: [103, 109] } },
  { id: "f3", enemyName: "Corte Rossa", pressure: 75, isMandatory: false,
    mission: { id: "m4", type: "annichilimento",   label: "Annichilimento",   difficulty: 0.40, rewardPool: [112, 111] } },
];

const NARRATIVE_EVENTS = [
  { id: "evt_01", title: "Il Canto si fa più forte", isAnomaly: false,
    body: [
      "Tra una missione e l'altra il Canto risuona — non come suono, ma come certezza. I tuoi Condensati si fermano. Si guardano.",
      "Il Richiamante si avvicina: «C'è una faglia che non abbiamo ancora visto. Dobbiamo andare?»",
      "Non sai perché, ma senti che la risposta giusta è già stata decisa.",
    ],
    choices: [
      { key: "advance", label: "«Seguite il Canto.»",  effect: "Orathai +20 pressione",   fn: (f) => f.map(x => x.enemyName === "Orathai" ? { ...x, pressure: Math.min(100, x.pressure + 20) } : x) },
      { key: "wait",    label: "«Aspettiamo.»",          effect: "Tutti i fronti -10",       fn: (f) => f.map(x => ({ ...x, pressure: Math.max(0, x.pressure - 10) })) },
    ],
  },
  { id: "evt_02", title: "Un ordine inspiegabile", isAnomaly: true,
    body: [
      "Arriva un comando attraverso il Canto. Nitido. Urgente.",
      "Retrocedete dal campo conquistato. Lasciatelo.",
      "Non c'è spiegazione. Il Canto non ne dà mai. Ma questa volta qualcosa è diverso — la voce ha una cadenza che non riconosci. Come se venisse da più lontano del solito.",
      "Serath si gira verso di te. «Hai sentito?» chiede. «Qualcosa non quadra.»",
    ],
    choices: [
      { key: "obey",   label: "Obbedite. Il Canto sa.",         effect: "Orathai -30 pressione",       fn: (f) => f.map(x => x.enemyName === "Orathai" ? { ...x, pressure: Math.max(0, x.pressure - 30) } : x) },
      { key: "resist", label: "«Aspettiamo. Voglio capire.»",   effect: "Nessuna conseguenza immediata", fn: (f) => f },
    ],
  },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const getCard      = (id) => FIGLI_CARDS.find(c => c.id === id);
const totalLeague  = (deck) => deck.reduce((s, id) => s + (getCard(id)?.league ?? 0), 0);
const missionColor = (t) => ({ assalto: C.amber, difesa: "#38bdf8", dominio: C.greenLit, annichilimento: C.redLit }[t] ?? C.violetLit);
const leagueColor  = (l) => ({ 2: C.textSec, 3: "#38bdf8", 4: C.violetLit, 5: C.amberLit }[l] ?? C.textSec);
const pressureCol  = (p) => p >= 80 ? C.redLit : p >= 50 ? C.amberLit : C.violetLit;

const TYPE_TAGS = {
  assalto:        { tag: "ASS", col: C.amber },
  difesa:         { tag: "DIF", col: "#38bdf8" },
  dominio:        { tag: "DOM", col: C.greenLit },
  annichilimento: { tag: "ANN", col: C.redLit },
};

const REWARD_PROFILE = {
  assalto:        { label: "Carte offensive",      col: C.amber },
  difesa:         { label: "Carte difensive",       col: "#38bdf8" },
  dominio:        { label: "Carte campo + modif.",  col: C.greenLit },
  annichilimento: { label: "Rare / Lega 5",         col: C.amberLit },
};

const TYPE_DESC = {
  assalto:        "Il giocatore ha iniziativa nei primi due turni. Vantaggio offensivo.",
  difesa:         "Il nemico ha iniziativa nei primi due turni. Premia la reazione.",
  dominio:        "Vittoria normale + conquista obbligatoria di un campo specifico.",
  annichilimento: "Vittoria solo per annientamento (avversario a 0 PV). High risk, high reward.",
};

// ─── STYLE HELPERS ───────────────────────────────────────────────────────────
const panel = (accent = C.violet, danger = false, p = 0) => ({
  background: danger && p >= 80 ? "#140808" : danger && p >= 50 ? "#130f05" : C.panelBg,
  border: `1px solid ${danger && p >= 80 ? "#2a0f0f" : danger && p >= 50 ? "#2a1f05" : C.border}`,
  borderLeft: `3px solid ${accent}`,
  padding: "14px 18px",
  fontFamily: FONTS.ui,
});

const btn = (color = C.violetLit, size = "sm") => ({
  fontFamily: FONTS.ui,
  fontWeight: 600,
  letterSpacing: "0.1em",
  fontSize: size === "lg" ? 14 : 12,
  color: color,
  background: `${color}10`,
  border: `1px solid ${color}40`,
  padding: size === "lg" ? "12px 20px" : "6px 14px",
  cursor: "pointer",
  textTransform: "uppercase",
  clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 8px 100%, 0 calc(100% - 8px))",
  display: "block",
  width: size === "lg" ? "100%" : "auto",
  textAlign: "left",
});

const label = (color = C.textMuted) => ({
  fontSize: 10,
  letterSpacing: "0.14em",
  color,
  fontFamily: FONTS.ui,
  fontWeight: 600,
  textTransform: "uppercase",
});

// ─── ATOMS ───────────────────────────────────────────────────────────────────

function SegBar({ value, max = 100, segments = 10, color }) {
  const filled = Math.ceil((value / max) * segments);
  return (
    <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
      {Array.from({ length: segments }).map((_, i) => (
        <div key={i} style={{ flex: 1, height: 7, background: i < filled ? color : C.border }} />
      ))}
    </div>
  );
}

function SectionHeader({ children, color = C.violetLit }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
      <div style={{ width: 3, height: 14, background: color, flexShrink: 0 }} />
      <span style={label(color)}>{children}</span>
      <div style={{ flex: 1, height: 1, background: C.border }} />
    </div>
  );
}

function StatBox({ label: lbl, value, color = C.textPri }) {
  return (
    <div style={{ background: C.panelBg2, border: `1px solid ${C.border}`, padding: "10px 14px" }}>
      <div style={label(C.textMuted)}>{lbl}</div>
      <div style={{ fontFamily: FONTS.mono, fontSize: 20, color, fontWeight: 700, marginTop: 4 }}>{value}</div>
    </div>
  );
}

function AgentRow({ cardId, onAdd, onRemove, compact = false }) {
  const card = getCard(cardId);
  if (!card) return null;
  const lc = leagueColor(card.league);
  return (
    <div style={{
      background: C.panelBg2,
      border: `1px solid ${C.border}`,
      borderLeft: `2px solid ${lc}50`,
      padding: compact ? "7px 12px" : "10px 14px",
      marginBottom: 4,
      display: "flex",
      alignItems: "flex-start",
      gap: 10,
      fontFamily: FONTS.ui,
    }}>
      {/* League pip */}
      <div style={{
        width: 28, height: 28, background: `${lc}15`,
        border: `1px solid ${lc}40`,
        display: "flex", alignItems: "center", justifyContent: "center",
        flexShrink: 0, fontFamily: FONTS.mono, fontSize: 10, color: lc, fontWeight: 700,
      }}>L{card.league}</div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 13, color: C.textPri, fontWeight: 600, letterSpacing: "0.03em" }}>
            {card.name}
          </span>
          {card.protagonist && (
            <span style={label(C.amberLit)}>★ protagonista</span>
          )}
        </div>
        {!compact && (
          <div style={{ display: "flex", gap: 14, marginTop: 5, flexWrap: "wrap", alignItems: "center" }}>
            {[["POT", card.pot, C.violetLit], ["DAN", card.dan, C.redLit]].map(([k, v, c]) => (
              <span key={k} style={{ fontFamily: FONTS.mono, fontSize: 11 }}>
                <span style={{ color: C.textMuted }}>{k} </span>
                <span style={{ color: c, fontWeight: 700 }}>{v}</span>
              </span>
            ))}
            <span style={{ fontSize: 11, color: C.textMuted }}>{card.trigger}</span>
            <span style={{ fontSize: 12, color: C.violetLit }}>{card.power}</span>
          </div>
        )}
        {compact && (
          <div style={{ marginTop: 2, fontFamily: FONTS.mono, fontSize: 10, color: C.textMuted }}>
            POT <span style={{ color: C.violetLit }}>{card.pot}</span>
            {" "}DAN <span style={{ color: C.redLit }}>{card.dan}</span>
            {" · "}{card.trigger}
          </div>
        )}
      </div>

      {onAdd && (
        <button onClick={() => onAdd(cardId)} style={{ ...btn(C.greenLit), padding: "4px 10px", fontSize: 11, width: "auto" }}>+</button>
      )}
      {onRemove && !card.protagonist && (
        <button onClick={() => onRemove(cardId)} style={{ ...btn(C.redLit), padding: "4px 10px", fontSize: 11, width: "auto" }}>−</button>
      )}
    </div>
  );
}

function BackBtn({ onClick }) {
  return (
    <button onClick={onClick} style={{ ...btn(C.textSec), width: "auto", marginBottom: 16, fontSize: 11 }}>
      ← Indietro
    </button>
  );
}

// ─── TOP HUD ─────────────────────────────────────────────────────────────────
function TopHUD({ day, hqIntegrity, deckSize, leagueUsed }) {
  const hqCol = hqIntegrity > 60 ? C.greenLit : hqIntegrity > 30 ? C.amberLit : C.redLit;
  return (
    <div style={{
      background: C.panelBg,
      borderBottom: `1px solid ${C.border}`,
      padding: "10px 24px",
      display: "flex",
      alignItems: "center",
      gap: 20,
      fontFamily: FONTS.ui,
      flexWrap: "wrap",
    }}>
      {/* Logo */}
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ width: 7, height: 7, background: C.violet, transform: "rotate(45deg)" }} />
        <span style={{ fontWeight: 700, letterSpacing: "0.22em", fontSize: 15, color: C.violetLit }}>SATZE</span>
      </div>

      <div style={{ width: 1, height: 18, background: C.border }} />

      <span style={{ fontSize: 12, color: C.textSec, letterSpacing: "0.06em" }}>Figli dell'Orizzonte</span>

      <div style={{ flex: 1 }} />

      {[
        { lbl: "Giorno",  val: String(day),         col: C.textPri },
        { lbl: "Deck",    val: `${deckSize}/10`,     col: C.violetLit },
        { lbl: "Lega",    val: `${leagueUsed}/30`,   col: leagueUsed > 26 ? C.amberLit : C.textPri },
      ].map(({ lbl, val, col }) => (
        <div key={lbl} style={{ textAlign: "center" }}>
          <div style={label(C.textMuted)}>{lbl}</div>
          <div style={{ fontFamily: FONTS.mono, fontSize: 15, color: col, marginTop: 2 }}>{val}</div>
        </div>
      ))}

      <div style={{ width: 1, height: 18, background: C.border }} />

      {/* HQ bar */}
      <div>
        <div style={{ ...label(C.textMuted), marginBottom: 4 }}>Sistema di Vaelith</div>
        <div style={{ display: "flex", gap: 2 }}>
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} style={{ width: 14, height: 8, background: i < Math.ceil(hqIntegrity / 10) ? hqCol : C.border }} />
          ))}
          <span style={{ fontFamily: FONTS.mono, fontSize: 11, color: hqCol, marginLeft: 6 }}>{hqIntegrity}%</span>
        </div>
      </div>
    </div>
  );
}

// ─── WAR MAP ─────────────────────────────────────────────────────────────────
function WarMapScreen({ state, onSelectMission, onEndDay }) {
  const { faglie, deck, hqIntegrity } = state;
  const [selFagliaId, setSelFagliaId] = useState(null);

  const selFaglia = faglie.find(f => f.id === selFagliaId) ?? null;

  const handleFagliaClick = (f) => {
    setSelFagliaId(selFagliaId === f.id ? null : f.id);
  };

  const handleConfirm = () => {
    if (selFaglia) onSelectMission(selFaglia, selFaglia.mission);
  };

  return (
    <div style={{ flex: 1, minHeight: 0, display: "grid", gridTemplateColumns: "1fr 300px", gap: 16, padding: "16px 0 16px 0", fontFamily: FONTS.ui, overflow: "hidden", alignItems: "start" }}>

    {/* ── LEFT COLUMN ── */}
    <div style={{ display: "flex", flexDirection: "column", padding: "0 20px", gap: 10, overflowY: "auto", height: "100%" }}>
      <SectionHeader>Mappa di guerra — Faglie attive</SectionHeader>

      {/* Each faglia + its reward panel are a row of the same grid — heights always match */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {faglie.map(f => {
          const p          = f.pressure;
          const pc         = pressureCol(p);
          const isSelected = selFagliaId === f.id;
          return (
            <div key={f.id} style={{ display: "grid", gridTemplateColumns: "1fr 200px", gap: 10, alignItems: "stretch" }}>

              {/* Faglia panel — entire panel is one button, always same size */}
              <div
                onClick={() => handleFagliaClick(f)}
                style={{
                  ...panel(pc, true, p),
                  outline: isSelected ? `1px solid ${pc}` : "1px solid transparent",
                  outlineOffset: -1,
                  cursor: "pointer",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                  <div style={{
                    width: 8, height: 8, flexShrink: 0,
                    background: isSelected ? pc : C.textMuted,
                    transform: "rotate(45deg)",
                  }} />
                  <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: "0.08em", color: C.textPri }}>
                    {f.enemyName.toUpperCase()}
                  </span>
                  {f.isMandatory && (
                    <span style={{
                      ...label(C.redLit), border: `1px solid ${C.red}`,
                      padding: "2px 8px", animation: "blink 1s infinite",
                    }}>!! Difesa obbligatoria</span>
                  )}
                  <div style={{ flex: 1 }} />
                  <span style={{ fontFamily: FONTS.mono, fontSize: 12, color: pc }}>{p}/100</span>
                </div>

                <SegBar value={p} color={pc} />

                {/* Single mission tag — display only */}
                {(() => {
                  const m  = f.mission;
                  const mc = missionColor(m.type);
                  const tt = TYPE_TAGS[m.type] ?? { tag: "---", col: mc };
                  return (
                    <div style={{ display: "flex", gap: 8, marginTop: 14, pointerEvents: "none" }}>
                      <div style={{ ...btn(mc), width: "auto", display: "flex", alignItems: "center", gap: 10 }}>
                        <span style={{
                          fontFamily: FONTS.mono, fontSize: 10, color: tt.col,
                          background: `${tt.col}20`, padding: "2px 6px",
                        }}>{tt.tag}</span>
                        {m.label}
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Reward panel — same height as faglia via stretch */}
              <div style={{
                background: C.panelBg2,
                border: `1px solid ${C.border}`,
                borderLeft: `3px solid ${isSelected ? pressureCol(p) : C.violetDim}`,
                padding: "14px",
                transition: "border-color 0.15s",
              }}>
                <div style={{ ...label(C.textMuted), marginBottom: 10 }}>Ricompense</div>
                {(() => {
                  const rp = REWARD_PROFILE[f.mission.type] ?? { label: "—", col: C.textMuted };
                  return (
                    <div style={{
                      fontFamily: FONTS.mono, fontSize: 11, color: rp.col,
                      background: isSelected ? `${rp.col}25` : `${rp.col}12`,
                      border: `1px solid ${isSelected ? rp.col + "80" : rp.col + "30"}`,
                      padding: "4px 8px", letterSpacing: "0.03em",
                    }}>
                      {rp.label}
                    </div>
                  );
                })()}
              </div>

            </div>
          );
        })}
      </div>

      {/* Confirm bar — 2 states: waiting / ready */}
      <div style={{
        minHeight: 48,
        flexShrink: 0,
        background: C.panelBg,
        border: `1px solid ${selFaglia ? C.borderHi : C.border}`,
        borderLeft: `3px solid ${selFaglia ? C.greenLit : C.border}`,
        padding: "0 16px",
        display: "flex", alignItems: "center", gap: 14,
      }}>
        {!selFaglia ? (
          <span style={{ fontSize: 12, color: C.textMuted }}>
            Seleziona una faglia per procedere.
          </span>
        ) : (
          <>
            <div style={{ width: 3, height: 14, background: C.greenLit, flexShrink: 0 }} />
            <span style={{ fontSize: 13, color: C.textSec }}>
              <span style={{ color: C.textPri, fontWeight: 600 }}>{selFaglia.enemyName}</span>
              {" — "}
              <span style={{ color: missionColor(selFaglia.mission.type) }}>{selFaglia.mission.label}</span>
            </span>
            <div style={{ flex: 1 }} />
            <button onClick={handleConfirm} style={{ ...btn(C.greenLit), width: "auto", fontSize: 13 }}>
              Conferma missione →
            </button>
          </>
        )}
      </div>

      {/* Deck strip + manage button */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 10, alignItems: "stretch", flexShrink: 0 }}>
        <div style={panel()}>
          <SectionHeader>Deck attivo ({deck.length}/10)</SectionHeader>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
            {deck.map(id => <AgentRow key={id} cardId={id} compact />)}
          </div>
        </div>
        <button style={{
          ...btn(C.violetLit),
          width: "auto", height: "100%",
          display: "flex", flexDirection: "column",
          alignItems: "center", justifyContent: "center",
          padding: "14px 18px",
          writingMode: "vertical-rl",
          letterSpacing: "0.14em",
          clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 8px 100%, 0 calc(100% - 8px))",
        }}>
          Gestisci deck
        </button>
      </div>

      <button onClick={onEndDay} style={{ ...btn(C.textSec, "lg"), display: "flex", justifyContent: "space-between", flexShrink: 0, marginTop: "auto" }}>
        <span>Fine giorno</span>
        <span style={{ fontFamily: FONTS.mono, fontSize: 11, color: C.textMuted }}>+15 pressione su tutti i fronti</span>
      </button>
    </div>

    {/* ── RIGHT COLUMN — tactical mini-map ── */}
    <TacticalMap faglie={faglie} selFagliaId={selFagliaId} hqIntegrity={hqIntegrity} onSelect={handleFagliaClick} />

    </div>
  );
}

// ─── TACTICAL MINI-MAP ───────────────────────────────────────────────────────
// Stable random positions seeded by faglia id
function seededRand(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  return Math.abs(h) / 2147483647;
}

function TacticalMap({ faglie, selFagliaId, hqIntegrity, onSelect }) {
  const W   = 290;
  const H   = 400;
  const hqX = W / 2;
  const hqY = H / 2;
  const hqR = 18;

  const hqCol = hqIntegrity > 60 ? C.greenLit : hqIntegrity > 30 ? C.amberLit : C.redLit;

  // Each faglia gets a stable random position scattered around HQ
  const slots = faglie.map((f, i) => {
    const r1 = seededRand(f.id + "x");
    const r2 = seededRand(f.id + "y");
    const r3 = seededRand(f.id + "side");
    // Spread evenly in angle space to avoid overlap
    const baseAngle = (i / faglie.length) * Math.PI * 2 + Math.PI * 0.1;
    const angleFuzz = (r1 - 0.5) * 0.6;
    const angle = baseAngle + angleFuzz;
    // Distance from HQ: pressure pushes closer
    const minDist = 60;
    const maxDist = 140;
    const dist = maxDist - (f.pressure / 100) * (maxDist - minDist);
    const x = hqX + Math.cos(angle) * dist;
    const y = hqY + Math.sin(angle) * dist;
    return { f, x: Math.max(20, Math.min(W - 20, x)), y: Math.max(20, Math.min(H - 20, y)) };
  });

  return (
    <div style={{
      background: C.panelBg,
      border: `1px solid ${C.border}`,
      borderLeft: `3px solid ${C.violetDim}`,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      marginRight: 20,
    }}>
      <div style={{ ...label(C.textMuted), padding: "12px 14px 8px", flexShrink: 0 }}>Fronte di guerra</div>

      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" style={{ display: "block", width: "100%" }}>

        {/* Subtle rings around HQ */}
        {[0.35, 0.65, 0.9].map(t => (
          <circle key={t}
            cx={hqX} cy={hqY}
            r={t * (Math.min(W, H) / 2 - 10)}
            fill="none" stroke={C.border} strokeWidth={0.5} strokeDasharray="3 5"
          />
        ))}

        {/* Lines from each faglia to HQ */}
        {slots.map(({ f, x, y }) => {
          const pc  = pressureCol(f.pressure);
          const sel = selFagliaId === f.id;
          // Line endpoint stops at HQ border
          const dx  = hqX - x;
          const dy  = hqY - y;
          const len = Math.sqrt(dx * dx + dy * dy);
          const ex  = hqX - (dx / len) * (hqR + 2);
          const ey  = hqY - (dy / len) * (hqR + 2);
          return (
            <line key={f.id + "_line"}
              x1={x} y1={y}
              x2={ex} y2={ey}
              stroke={sel ? pc : C.textMuted}
              strokeWidth={sel ? 1.5 : 0.5}
              strokeDasharray={f.pressure > 75 ? "0" : "4 3"}
              opacity={sel ? 1 : 0.35}
            />
          );
        })}

        {/* HQ node — center */}
        <circle cx={hqX} cy={hqY} r={hqR}
          fill={C.panelBg2} stroke={hqCol} strokeWidth={2}
        />
        <text x={hqX} y={hqY + 4}
          textAnchor="middle" fill={hqCol}
          fontSize={9} fontFamily={FONTS.mono} letterSpacing="0.1em"
        >HQ</text>

        {/* HQ integrity arc */}
        {(() => {
          const r   = hqR + 5;
          const pct = hqIntegrity / 100;
          const ang = pct * Math.PI * 2 - Math.PI / 2;
          const x2  = hqX + r * Math.cos(ang);
          const y2  = hqY + r * Math.sin(ang);
          const lg  = pct > 0.5 ? 1 : 0;
          if (pct <= 0) return null;
          if (pct >= 1) return (
            <circle cx={hqX} cy={hqY} r={r} fill="none" stroke={hqCol} strokeWidth={1.5} opacity={0.5} />
          );
          return (
            <path
              d={`M ${hqX} ${hqY - r} A ${r} ${r} 0 ${lg} 1 ${x2} ${y2}`}
              fill="none" stroke={hqCol} strokeWidth={1.5} opacity={0.5}
            />
          );
        })()}

        {/* Faglia nodes */}
        {slots.map(({ f, x, y }) => {
          const pc  = pressureCol(f.pressure);
          const sel = selFagliaId === f.id;
          const r   = sel ? 10 : 8;
          // Label above or below based on y position relative to HQ
          const labelY = y < hqY ? y - r - 14 : y + r + 10;
          const pressY = y < hqY ? y - r - 5  : y + r + 19;
          return (
            <g key={f.id} onClick={() => onSelect(f)} style={{ cursor: "pointer" }}>
              {sel && (
                <circle cx={x} cy={y} r={r + 6} fill="none" stroke={pc} strokeWidth={1} opacity={0.3} />
              )}
              {f.isMandatory && (
                <circle cx={x} cy={y} r={r + 4} fill="none" stroke={C.redLit} strokeWidth={1} opacity={0.7} strokeDasharray="2 2" />
              )}
              <circle cx={x} cy={y} r={r}
                fill={sel ? `${pc}30` : C.panelBg2}
                stroke={pc} strokeWidth={sel ? 2 : 1}
              />
              <circle cx={x} cy={y} r={3} fill={pc} opacity={0.9} />
              <text x={x} y={labelY}
                textAnchor="middle" fill={sel ? C.textPri : C.textSec}
                fontSize={8} fontFamily={FONTS.ui}
                fontWeight={sel ? "600" : "400"} letterSpacing="0.04em"
              >
                {f.enemyName.toUpperCase().slice(0, 6)}
              </text>
              <text x={x} y={pressY}
                textAnchor="middle" fill={pc}
                fontSize={7} fontFamily={FONTS.mono}
              >
                {f.pressure}%
              </text>
            </g>
          );
        })}

      </svg>
    </div>
  );
}

// ─── MISSION SETUP ────────────────────────────────────────────────────────────
function MissionSetupScreen({ faglia, mission, deck, onStart, onBack }) {
  const mc  = missionColor(mission.type);
  const tt  = TYPE_TAGS[mission.type] ?? { tag: "---", col: mc };
  const lg  = totalLeague(deck);

  return (
    <div style={{ padding: "16px 24px", fontFamily: FONTS.ui, height: "100%", overflowY: "auto" }}>
      <BackBtn onClick={onBack} />

      {/* Mission header */}
      <div style={{ ...panel(mc), marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
          <span style={{
            fontFamily: FONTS.mono, fontSize: 10, color: tt.col,
            background: `${tt.col}20`, padding: "3px 8px",
          }}>{tt.tag}</span>
          <span style={label(C.textMuted)}>vs. {faglia.enemyName}</span>
        </div>
        <div style={{ fontSize: 24, fontWeight: 700, letterSpacing: "0.06em", color: C.textPri, marginBottom: 8 }}>
          {mission.label.toUpperCase()}
        </div>
        <div style={{ fontSize: 13, color: C.textSec, lineHeight: 1.65 }}>{TYPE_DESC[mission.type]}</div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
        <StatBox label="Pressione fronte"     value={`${faglia.pressure}/100`} color={pressureCol(faglia.pressure)} />
        <StatBox label="Carte in deck"        value={String(deck.length)} />
        <StatBox label="Lega utilizzata"      value={`${lg}/30`} color={lg > 26 ? C.amberLit : C.textPri} />
      </div>

      {/* Deck */}
      <div style={{ ...panel(), marginBottom: 16 }}>
        <SectionHeader>Deck al momento della battaglia</SectionHeader>
        {deck.map(id => <AgentRow key={id} cardId={id} />)}
      </div>

      <button onClick={onStart} style={{ ...btn(mc, "lg") }}>
        Inizia la battaglia →
      </button>
    </div>
  );
}

// ─── BATTLE ──────────────────────────────────────────────────────────────────
function BattleScreen({ mission, faglia, deck, onResult }) {
  const [phase, setPhase] = useState("ready");
  const [won, setWon]     = useState(null);
  const mc = missionColor(mission.type);

  const simulate = () => {
    setPhase("simulating");
    setTimeout(() => {
      const r = Math.random() < mission.difficulty;
      setWon(r);
      setPhase("done");
    }, 1600);
  };

  return (
    <div style={{ padding: "16px 24px", fontFamily: FONTS.ui, height: "100%", overflowY: "auto" }}>
      {/* VS banner */}
      <div style={{
        background: C.panelBg, border: `1px solid ${C.border}`, borderTop: `3px solid ${mc}`,
        padding: "16px 24px", marginBottom: 16, textAlign: "center",
      }}>
        <div style={label(mc)}>{mission.label}</div>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: "0.06em", color: C.textPri, marginTop: 6 }}>
          Figli dell'Orizzonte
          <span style={{ color: C.textMuted, margin: "0 16px", fontSize: 14 }}>VS</span>
          {faglia.enemyName.toUpperCase()}
        </div>
      </div>

      {/* Deck */}
      <div style={{ ...panel(), marginBottom: 16 }}>
        <SectionHeader>Il tuo deck</SectionHeader>
        {deck.map(id => <AgentRow key={id} cardId={id} />)}
      </div>

      {phase === "ready" && (
        <button onClick={simulate} style={{ ...btn(C.violetLit, "lg") }}>
          Simula battaglia →
        </button>
      )}

      {phase === "simulating" && (
        <div style={{
          background: C.panelBg, border: `1px solid ${C.border}`,
          padding: "28px", textAlign: "center",
        }}>
          <div style={label(C.textMuted)}>Calcolo in corso</div>
          <div style={{ display: "flex", gap: 4, justifyContent: "center", marginTop: 12 }}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} style={{ width: 7, height: 7, background: i % 2 === 0 ? C.violetLit : C.border }} />
            ))}
          </div>
        </div>
      )}

      {phase === "done" && (
        <div style={{
          background: won ? "#0a1a0a" : "#1a0808",
          border: `1px solid ${won ? C.green : C.red}`,
          borderTop: `3px solid ${won ? C.greenLit : C.redLit}`,
          padding: "24px", textAlign: "center",
        }}>
          <div style={{
            fontSize: 36, fontWeight: 700, letterSpacing: "0.1em",
            color: won ? C.greenLit : C.redLit, marginBottom: 10,
          }}>
            {won ? "VITTORIA" : "SCONFITTA"}
          </div>
          <div style={{ fontSize: 13, color: C.textSec, marginBottom: 20 }}>
            {won
              ? `La faglia di ${faglia.enemyName} è stata chiusa.`
              : "Segmento gestionale ridotto. Meno opzioni disponibili."}
          </div>
          <button onClick={() => onResult(won)} style={{ ...btn(won ? C.greenLit : C.redLit, "lg") }}>
            Continua →
          </button>
        </div>
      )}
    </div>
  );
}

// ─── MISSION RESULT ───────────────────────────────────────────────────────────
function MissionResultScreen({ won, mission, warehouse, onClaim, onSkip }) {
  const [rewardId] = useState(() => {
    const pool = mission.rewardPool.filter(id => !warehouse.includes(id));
    return pool.length > 0 ? pool[Math.floor(Math.random() * pool.length)] : mission.rewardPool[0];
  });
  const reward      = getCard(rewardId);
  const alreadyOwned = warehouse.includes(rewardId);

  if (!won) {
    return (
      <div style={{ padding: "20px 24px" }}>
        <div style={{ ...panel(C.redLit), marginBottom: 16 }}>
          <SectionHeader color={C.redLit}>Sconfitta — nessuna ricompensa</SectionHeader>
          <p style={{ fontSize: 13, color: C.textSec, lineHeight: 1.7 }}>
            Il segmento gestionale sarà ridotto. Hai meno opzioni per gestire il deck e gli eventi narrativi.
          </p>
        </div>
        <button onClick={() => onSkip(false)} style={{ ...btn(C.textSec, "lg") }}>
          Continua al segmento gestionale →
        </button>
      </div>
    );
  }

  const lc = reward ? leagueColor(reward.league) : C.textSec;

  return (
    <div style={{ padding: "16px 24px", fontFamily: FONTS.ui, height: "100%", overflowY: "auto" }}>
      <SectionHeader color={C.greenLit}>Vittoria — Ricompensa</SectionHeader>

      {reward && (
        <div style={{ ...panel(lc), background: "#0a100a", marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: C.textPri, letterSpacing: "0.04em" }}>{reward.name}</div>
              <div style={{ display: "flex", gap: 14, marginTop: 6 }}>
                {[["POT", reward.pot, C.violetLit], ["DAN", reward.dan, C.redLit]].map(([k, v, c]) => (
                  <span key={k} style={{ fontFamily: FONTS.mono, fontSize: 11 }}>
                    <span style={{ color: C.textMuted }}>{k} </span>
                    <span style={{ color: c, fontWeight: 700 }}>{v}</span>
                  </span>
                ))}
              </div>
            </div>
            <div style={{
              fontFamily: FONTS.mono, fontSize: 11, color: lc,
              background: `${lc}18`, border: `1px solid ${lc}40`,
              padding: "4px 10px", letterSpacing: "0.06em",
            }}>LEGA {reward.league}</div>
          </div>
          <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>{reward.trigger}</div>
          <div style={{ fontSize: 13, color: C.violetLit }}>{reward.power}</div>
          {reward.leagueGated && (
            <div style={{ marginTop: 10, fontSize: 11, color: C.amberLit, border: `1px solid ${C.amber}30`, padding: "6px 10px" }}>
              Carta Lega 5 — solo da Annichilimento o missioni speciali.
            </div>
          )}
          {alreadyOwned && (
            <div style={{ marginTop: 8, fontSize: 11, color: C.textMuted }}>Già nel magazzino.</div>
          )}
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8 }}>
        <button
          onClick={() => onClaim(rewardId)}
          disabled={alreadyOwned}
          style={{ ...btn(C.greenLit, "lg"), margin: 0, opacity: alreadyOwned ? 0.4 : 1, cursor: alreadyOwned ? "not-allowed" : "pointer" }}
        >
          Aggiungi al magazzino →
        </button>
        <button onClick={() => onSkip(true)} style={{ ...btn(C.textSec), width: "auto" }}>Salta</button>
      </div>
    </div>
  );
}

// ─── GESTIONAL ────────────────────────────────────────────────────────────────
function GestionalScreen({ state, reduced, onAddToDeck, onRemoveFromDeck, onDone }) {
  const { deck, warehouse } = state;
  const lg = totalLeague(deck);
  const canAdd = (id) => {
    const card = getCard(id);
    return !reduced && deck.length < 10 && lg + (card?.league ?? 0) <= 30 && !deck.includes(id);
  };

  return (
    <div style={{ padding: "16px 24px", fontFamily: FONTS.ui, height: "100%", overflowY: "auto" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 14 }}>
        <div>
          <SectionHeader color={reduced ? C.amberLit : C.violetLit}>
            Segmento gestionale{reduced ? " — ridotto" : ""}
          </SectionHeader>
          {reduced && (
            <div style={{ fontSize: 12, color: C.amberLit, marginTop: -8, marginBottom: 10 }}>
              Sconfitta: puoi rivedere il deck ma non modificarlo.
            </div>
          )}
        </div>
        <button onClick={onDone} style={{ ...btn(C.violetLit), width: "auto" }}>Fine gestione →</button>
      </div>

      {/* Stats strip */}
      <div style={{ display: "flex", gap: 16, marginBottom: 16 }}>
        {[
          { lbl: "Deck",      val: `${deck.length}/10`, col: C.textPri },
          { lbl: "Lega",      val: `${lg}/30`,           col: lg > 26 ? C.amberLit : C.textPri },
          { lbl: "Magazzino", val: String(warehouse.length), col: C.textSec },
        ].map(({ lbl, val, col }) => (
          <div key={lbl}>
            <div style={label(C.textMuted)}>{lbl}</div>
            <div style={{ fontFamily: FONTS.mono, fontSize: 17, color: col, marginTop: 3 }}>{val}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div>
          <SectionHeader>Magazzino</SectionHeader>
          {warehouse.length === 0
            ? <div style={{ fontSize: 12, color: C.textMuted, fontStyle: "italic" }}>Vuoto</div>
            : warehouse.map(id => <AgentRow key={id} cardId={id} onAdd={canAdd(id) ? onAddToDeck : null} />)
          }
        </div>
        <div>
          <SectionHeader>Deck attivo</SectionHeader>
          {deck.map(id => <AgentRow key={id} cardId={id} onRemove={!reduced ? onRemoveFromDeck : null} />)}
        </div>
      </div>
    </div>
  );
}

// ─── NARRATIVE ────────────────────────────────────────────────────────────────
function NarrativeScreen({ event, onChoice }) {
  const anomaly = event.isAnomaly;
  const accent  = anomaly ? C.redLit : C.violetLit;

  return (
    <div style={{ padding: "16px 24px", fontFamily: FONTS.ui, height: "100%", overflowY: "auto" }}>
      <div style={{
        background: anomaly ? "#100606" : C.panelBg,
        border: `1px solid ${anomaly ? "#2a0808" : C.border}`,
        borderTop: `3px solid ${accent}`,
        padding: "20px 24px",
        marginBottom: 16,
      }}>
        <div style={{ ...label(accent), marginBottom: 10 }}>
          {anomaly ? "◈  — — —  Anomalia  — — —  ◈" : "Evento narrativo"}
        </div>
        <div style={{
          fontSize: anomaly ? 19 : 22, fontWeight: 700,
          letterSpacing: "0.04em", color: anomaly ? C.redLit : C.textPri,
          marginBottom: 18, fontStyle: anomaly ? "italic" : "normal",
        }}>
          {event.title}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {event.body.map((line, i) => (
            <p key={i} style={{
              fontSize: 14, color: C.textSec, lineHeight: 1.75, margin: 0,
              borderLeft: anomaly && i === event.body.length - 1 ? `2px solid ${C.red}40` : "none",
              paddingLeft: anomaly && i === event.body.length - 1 ? 12 : 0,
            }}>{line}</p>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {event.choices.map(choice => (
          <button
            key={choice.key}
            onClick={() => onChoice(choice)}
            style={{
              ...btn(accent, "lg"),
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}
          >
            <span>{choice.label}</span>
            <span style={{ fontFamily: FONTS.mono, fontSize: 11, color: C.textMuted }}>{choice.effect}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function CampaignPrototype() {
  useEffect(() => { injectFonts(); }, []);

  const [phase, setPhase]               = useState("war_map");
  const [selFaglia, setSelFaglia]       = useState(null);
  const [battleWon, setBattleWon]       = useState(null);
  const [narrativeIdx, setNarrativeIdx] = useState(0);
  const [showNarrative, setShowNarrative] = useState(false);
  const [missionCount, setMissionCount] = useState(0);

  const [camp, setCamp] = useState({
    day: 1, hqIntegrity: 100,
    deck:      [...INITIAL_DECK],
    warehouse: [...INITIAL_WAREHOUSE],
    faglie: INITIAL_FAGLIE.map(f => ({ ...f })),
  });

  const onSelectMission = (faglia, mission) => { setSelFaglia(faglia); setPhase("setup"); };
  const onBattleResult  = (won) => { setBattleWon(won); setPhase("result"); };

  const afterMission = () => {
    const next = missionCount + 1;
    setMissionCount(next);
    if (next >= 2 && narrativeIdx < NARRATIVE_EVENTS.length) setShowNarrative(true);
    setPhase("gestional");
  };

  const onClaim = (rewardId) => {
    setCamp(s => ({
      ...s,
      warehouse: rewardId && !s.warehouse.includes(rewardId) ? [...s.warehouse, rewardId] : s.warehouse,
      faglie: s.faglie.map(f => f.id === selFaglia.id ? { ...f, pressure: 0, isMandatory: false } : f),
    }));
    afterMission();
  };

  const onSkipReward = (won) => {
    setCamp(s => ({
      ...s,
      hqIntegrity: !won ? Math.max(0, s.hqIntegrity - (selFaglia.isMandatory ? 20 : 5)) : s.hqIntegrity,
      faglie: s.faglie.map(f =>
        f.id === selFaglia.id
          ? won
            ? { ...f, pressure: 0, isMandatory: false }
            : { ...f, pressure: Math.min(100, f.pressure + 20), isMandatory: f.pressure + 20 >= 100 }
          : f
      ),
    }));
    afterMission();
  };

  const onNarrativeChoice = (choice) => {
    setCamp(s => ({ ...s, faglie: choice.fn(s.faglie) }));
    setNarrativeIdx(i => i + 1);
    setMissionCount(0);
    setShowNarrative(false);
  };

  const onAddToDeck = (id) => setCamp(s => {
    const card = getCard(id);
    if (s.deck.length >= 10 || totalLeague(s.deck) + (card?.league ?? 0) > 30) return s;
    return { ...s, deck: [...s.deck, id], warehouse: s.warehouse.filter(w => w !== id) };
  });

  const onRemoveFromDeck = (id) => {
    if (getCard(id)?.protagonist) return;
    setCamp(s => ({ ...s, deck: s.deck.filter(d => d !== id), warehouse: [...s.warehouse, id] }));
  };

  const onEndDay = () => setCamp(s => ({
    ...s, day: s.day + 1,
    faglie: s.faglie.map(f => {
      const np = Math.min(100, f.pressure + 15);
      return { ...f, pressure: np, isMandatory: np >= 100 };
    }),
  }));

  const lg = totalLeague(camp.deck);
  const currentNarrative = NARRATIVE_EVENTS[narrativeIdx];

  return (
    <div style={{ height: "100vh", background: C.bg, color: C.textPri, fontFamily: FONTS.ui, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <style>{`
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.4} }
        button:hover { filter: brightness(1.15); }
        button:active { transform: scale(0.98); }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        p { margin: 0; }
        ::-webkit-scrollbar { width: 4px; } 
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #1a2030; border-radius: 2px; }
      `}</style>

      <TopHUD
        day={camp.day}
        hqIntegrity={camp.hqIntegrity}
        deckSize={camp.deck.length}
        leagueUsed={lg}
      />

      <div style={{ flex: 1, minHeight: 0, maxWidth: 1100, width: "100%", margin: "0 auto", display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {phase === "war_map" && (
          <WarMapScreen state={camp} onSelectMission={onSelectMission} onEndDay={onEndDay} />
        )}
        {phase === "setup" && selFaglia && (
          <MissionSetupScreen
            faglia={selFaglia} mission={selFaglia.mission} deck={camp.deck}
            onStart={() => setPhase("battle")} onBack={() => setPhase("war_map")}
          />
        )}
        {phase === "battle" && selFaglia && (
          <BattleScreen
            mission={selFaglia.mission} faglia={selFaglia} deck={camp.deck}
            onResult={onBattleResult}
          />
        )}
        {phase === "result" && selFaglia && (
          <MissionResultScreen
            won={battleWon} mission={selFaglia.mission} warehouse={camp.warehouse}
            onClaim={onClaim} onSkip={onSkipReward}
          />
        )}
        {phase === "gestional" && (
          showNarrative && currentNarrative
            ? <NarrativeScreen event={currentNarrative} onChoice={onNarrativeChoice} />
            : <GestionalScreen
                state={camp} reduced={!battleWon}
                onAddToDeck={onAddToDeck} onRemoveFromDeck={onRemoveFromDeck}
                onDone={() => setPhase("war_map")}
              />
        )}
      </div>
    </div>
  );
}
