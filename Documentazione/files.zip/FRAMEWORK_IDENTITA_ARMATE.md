# SATZE — FRAMEWORK IDENTITÀ ARMATE

*Documento di design: distribuzione trigger, effetti e combinazioni per armata*

---

## CONCETTI CHIAVE

### Trigger Convergenti vs Asso

- **Convergente:** la condizione del trigger si allinea naturalmente col gameplan dell'armata e/o col bonus armata. La carta raggiunge il suo potenziale massimo quando il piano funziona.
- **Asso:** la condizione del trigger è in tensione col gameplan o col bonus. La carta non raggiunge mai il 100% del potenziale, ma è versatile — funziona in situazioni dove le carte convergenti no. Se il bonus è attivo, il potere non lo è; se il potere è attivo, il bonus non lo è.
- **Neutro:** trigger senza tensione specifica (es. Sempre, Resa dei conti su armate senza preferenza temporale).

### Effetti Convergenti vs Asso

Stessa logica applicata agli effetti:

- **Convergente:** l'effetto rinforza il gameplan, si stacka col bonus, amplifica l'identità.
- **Asso:** l'effetto dà valore ma non amplifica l'identità core. Apre vie alternative.

### Eccezioni Trigger+Effetto

Alcune combinazioni cambiano natura in base all'abbinamento:

- Un effetto asso su trigger convergente = carta ibrida (forte nel flusso naturale ma con un effetto "fuori tema")
- Un effetto convergente su trigger asso = carta ibrida inversa (l'effetto è giusto ma si attiva nel momento "sbagliato")
- Trigger asso + effetto asso = carta doppiamente asso (mai allineata al gameplan, ceiling altissimo in situazioni rare)

### Distribuzione Asso per Armata

Lo **Sciame Divorante** ha il rapporto asso/convergenti più alto (~50/50). Le altre armate hanno più convergenti (~60-65%) e meno asso (~25-30%), con il resto neutro. Il **Circolo Mistico** è un caso speciale: distribuzione piatta senza dominanza.

---

## ⚙️ CALIBRI PESANTI

**Bonus:** -2 DAN nem. (min 2) [Sempre]

### Gameplan

"Perdi in piccolo, vinci in grande." Investi 1-2 FC nei turni sacrificali, poi 5+ FC nei 2-3 duelli chiave con Overdrive. Il bonus mitiga il danno subito nei turni dove perdi volontariamente. Obiettivo: arrivare a T5 con più PV per Supremazia.

Lo stato principale dell'armata è **perdere la maggior parte dei turni investendo poco**. Overdrive è l'eccezione esplosiva, non la norma.

### Trigger

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Overdrive | 4-5 | Il turno chiave dove investi 5+ FC. La firma dell'armata. |
| Convergente | Vendetta | 2 | Perdi il turno prima → attivo. Lo stato naturale dei Calibri. |
| Convergente | Ultimo Desiderio | 2 | Stai perdendo il duello → fai valore comunque. |
| Convergente | Rimonta | 1 | Sotto PV nei turni dove perdi spesso. |
| Asso | Gloria | 2 | Dopo il turno Overdrive vinto, hai Gloria ma non puoi sempre spendere altri 5 FC. Capitalizza il momentum senza costo. |
| Asso | Magnanimo | 1 | Dopo le vittorie sei sopra PV grazie al bonus -DAN. Forte ma mai allineato col "perdi spesso". |
| Asso | Imboscata | 1-2 | Giochi primo con investimento grosso. Potenza pura, nessuna protezione. |
| Neutro | Sempre | 1-2 | Carte solide senza condizione. |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | -DAN nem. | 2-3 | Stacka col bonus. Nei turni dove perdi, subisci quasi nulla. |
| Convergente | Immune | 1-2 | Protezione totale nel turno Overdrive. Nessun debuff ti ferma. |
| Convergente | Cura | 1-2 | Recupero PV per consolidare il vantaggio vita verso T5. |
| Convergente | +FC | 1-2 | Ricarica risorse dopo aver speso grosso. Permette un secondo Overdrive. |
| Asso | +POT | 2-3 | Inutile nei turni da 1 FC, esplosiva nei turni Overdrive (POT×5FC). Mai allineata col "perdi spesso" ma ceiling enorme. |
| Asso | DAN dir. | 1-2 | Via alternativa per fare danno senza vincere. |

**Eccezione:** DAN dir. + Ultimo Desiderio/Vendetta diventa convergente (perdi → fai danno comunque → coerente). DAN dir. + Conquista/Gloria resta asso (stai già vincendo, ridondante).

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Overdrive + Immune | Convergente pieno | IL turno blindato. Investi tutto, nessun debuff ti ferma. La carta dei Calibri. |
| Overdrive + +POT | Trigger conv. + effetto asso | Il turno esplosivo. +POT × 5+ FC = VA enorme. Nessuna protezione. |
| Vendetta + +FC | Convergente pieno | Perdi → recuperi risorse → secondo Overdrive possibile. Ciclo economico. |
| Vendetta + Cura | Convergente pieno | Perdi → ti curi → bonus già riduce DAN. Doppia mitigazione. |
| Ultimo Desiderio + DAN dir. | Convergente pieno | Perdi il duello, fai danno comunque. Missile sacrificale. |
| Ultimo Desiderio + -DAN nem. | Convergente pieno | Perdi → riduci danno subito ulteriormente. Stacka col bonus. |
| Gloria + alto DAN base | Asso | Dopo Overdrive vinto, giochi questa con pochi FC. Il DAN alto fa male comunque. |
| Magnanimo + Cura | Asso | Sopra PV dopo vittoria, ti consolidi per Supremazia T5. |
| Imboscata + +POT alto | Asso | Giochi primo con investimento grosso. Solo potenza pura. |
| Sempre + -DAN nem. + corpo alto | Neutro | La carta "muro" sempre disponibile. |

### Identità

Nucleo difensivo (molti -DAN, Cura, Immune) resiliente nei turni di sconfitta + 4-5 carte Overdrive come "bombe" nei turni chiave. Le carte asso Gloria/Magnanimo capitalizzano il momentum post-vittoria senza richiedere altri 5 FC. Tensione costante: "questo turno perdo di proposito o è il turno all-in?"

---

## ☄️ COMETE

**Bonus:** -5 VA nem. (min 6) [Sempre]

### Gameplan

"Efficienza e controllo." Il bonus equalizza il VA, quindi vinci investendo meno FC del nemico. Accumuli vantaggio di risorse, prolunghi la partita, vinci per superiorità a lungo termine.

### Trigger

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Resa dei conti | 3-4 | Partite lunghe, attivo dal T3+. L'armata che beneficia di più del late game. |
| Convergente | Gloria | 2-3 | Le vittorie efficienti generano momentum. |
| Neutro | Sempre | 2-3 | Stabilità costante, coerente col bonus Sempre. |
| Asso | Imboscata | 2 | L'armata preferisce giocare seconda (informazione). Giocare primo è un rischio. |
| Asso | Vendetta | 1-2 | Perdere un turno non è nel piano efficienza. Ma capita. |
| Asso | Conquista | 1 | Vincere è il risultato, non l'obiettivo primario (l'obiettivo è l'efficienza). |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | -VA nem. | 3-4 | Firma assoluta. Stacka col bonus. Soffocamento. |
| Convergente | +FC | 2-3 | Economia. Vinci spendendo meno, accumuli di più. |
| Convergente | Copia POT | 1 | Il bonus equalizza il VA, copiare POT nemica ti mette in vantaggio. |
| Convergente | Blocca Potere/Bonus | 1-2 | Controllo. Complementare al soffocamento VA. |
| Asso | DAN dir. | 2 | Chiusura aggressiva. Va contro la pazienza del controllo. |
| Asso | +POT/+DAN | 1-2 | Buff diretto, più da armata aggressiva che da controllore. |

**Eccezione:** Cura + Conquista diventa convergente (vinci con efficienza → ti curi → allunghi vantaggio PV per T5).

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Resa dei conti + -VA nem. | Convergente pieno | La carta definitiva del late game. Bonus -5 VA + potere -4/6 VA. Nemico soffocato. |
| Resa dei conti + Blocca Potere | Convergente pieno | Neutralizzi il potere nemico nei turni finali. Il tuo bonus fa il resto. |
| Resa dei conti + DAN dir. | Trigger conv. + effetto asso | Il closer. Partite lunghe, entrambi con pochi FC, DAN dir. chiude. |
| Gloria + +FC | Convergente pieno | Vinci con efficienza → guadagni più risorse. Snowball economico. |
| Sempre + -VA nem. | Convergente pieno | Debuff costante senza condizioni. |
| Sempre + Blocca Bonus | Convergente pieno | Neutralizzi il bonus nemico permanentemente. |
| Imboscata + DAN dir. | Asso pieno | L'asteroide che colpisce senza preavviso. Fuori identità ma sorpresa pura. |
| Imboscata + +FC | Asso | Giochi primo e guadagni risorse. Opzione quando sei forzato a giocare primo. |
| Vendetta + Copia POT | Asso | Perdi → copi POT del nemico. Col bonus -5 VA, il turno dopo hai POT alta e VA nemico ridotto. Sconfitta come setup. |

### Identità

L'armata soffocatrice. Ogni turno il nemico ha meno VA, meno opzioni. Le Comete non uccidono, strangolano. Nucleo: -VA e +FC su trigger affidabili (Resa dei conti, Sempre). Carte asso aggressive (DAN dir., Imboscata) per quando serve chiudere. Tensione: "continuo a controllare o è il momento di finirla?"

---

## 🏛 PROGENIE DI BABELE

**Bonus:** Rimonta: +2 POT

### Gameplan

"Cadere per rialzarsi più forte." Perdi i primi turni (volontariamente o meno), attivi Rimonta per +2 POT, le carte comeback diventano devastanti. L'auto-danno è una feature, non un bug.

Due fasi: **Fase 1** (sotto PV) → carte convergenti dominano, tutto si somma. **Fase 2** (sopra PV dopo comeback) → carte asso entrano in gioco, forti ma senza bonus.

### Trigger

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Vendetta | 3-4 | Hai perso → sei sotto PV → Rimonta attiva → sinergia doppia. |
| Convergente | Ultimo Desiderio | 3 | Stai perdendo il duello → fai danno/valore → resti sotto PV. |
| Convergente | Rimonta | 2 | Condizione identica al bonus. Doppia attivazione. |
| Asso | Gloria | 2-3 | Hai vinto → probabilmente il piano "stai sotto PV" vacilla. Forte ma il bonus potrebbe essere spento. |
| Asso | Magnanimo | 1-2 | Sei sopra PV → bonus Rimonta spento. Mai +4 POT, sempre solo +2 da una fonte. |
| Neutro | Sempre | 1 | Carta solida. |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | +POT | 4-5 | Firma dell'armata. Stacka col bonus +2 POT. Nimrod ha POT 7 base. |
| Convergente | -PV a te | 1-2 | Auto-danno per attivare Rimonta. Pietra Angolare è il design perfetto. |
| Convergente | DAN dir. | 2-3 | Danno anche perdendo. Mantieni pressione. |
| Asso | Cura | 1-2 | Utile per non morire, pericolosa per il gameplan (rischi di spegnere Rimonta). |
| Asso | Immune | 1 | Protezione, non rinforza il tema aggressivo comeback. |
| Asso | +DAN | 1-2 | Non è l'identità POT-centrica. Funziona ma non amplifica. |
| Asso | Blocca Bonus | 1 | Utilità. |

**Eccezione:** Cura su Ultimo Desiderio è meno asso del solito — se stai perdendo E sei sotto PV, 2 PV di cura raramente ti portano sopra la soglia Rimonta. Quasi convergente in contesto.

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Vendetta + +POT alto | Convergente pieno | IL cuore della Progenie. Perdi → sotto PV → Rimonta +2 → potere +POT. Il guerriero caduto che si rialza. |
| Vendetta + DAN dir. | Convergente pieno | Perdi, fai danno diretto comunque. Pressione anche perdendo. |
| Ultimo Desiderio + DAN dir. | Convergente pieno | Il kamikaze. Perdi il duello, fai danno, resti sotto PV per Rimonta. |
| Ultimo Desiderio + Cura | Ibrido | Perdi ma ti curi un po'. In pratica raramente esci da Rimonta. |
| Rimonta + Copia POT | Convergente pieno | Sotto PV, copi POT del nemico forte + bonus +2 POT. Ceiling astronomico. |
| Rimonta + Immune | Convergente pieno | Sotto PV, inattaccabile dai debuff. La torre caduta che non crolla più. |
| -PV a te + qualsiasi trigger | Convergente | L'auto-danno come strumento per attivare Rimonta volontariamente. |
| Gloria + +POT | Asso | Hai vinto (comeback riuscito), +POT dal potere, ma Rimonta potrebbe essere spenta. |
| Magnanimo + DAN dir. | Asso | Sopra PV, fai danno diretto per chiudere prima che la situazione si ribalti. |
| Magnanimo + +POT | Asso | Ur-Nammu. Sopra PV, +2 POT dal potere ma non +2 dal bonus. Mai +4 totali. |

### Identità

Fase 1 (sotto PV): convergenti dominano, macchina da comeback. Fase 2 (sopra PV): asso entrano in gioco, forti senza bonus. Tensione: "il comeback è riuscito, chiudo con le asso o mi rimetto sotto PV per il bonus?"

---

## 😈 CORTE DEI DIAVOLI

**Bonus:** Copia Bonus nemico [Sempre]

### Gameplan

"Parassita perfetto." Copia, ruba, manipola. Gioca seconda per informazione. L'identità della Corte È quella del nemico, rubata o cancellata.

### Trigger

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Intervento | 4-5 | Giochi seconda → vedi il nemico → copi/blocchi. Firma. |
| Convergente | Resa dei conti | 2-3 | Più turni = più info = parassitismo più efficace. |
| Neutro | Sempre | 1-2 | Carte solide senza condizione. |
| Asso | Imboscata | 2 | Giochi prima, senza informazione. Il diavolo che agisce d'anticipo. |
| Asso | Vendetta | 2 | La Corte non vuole perdere. Ma se perde, valore di recupero. |
| Asso | Conquista | 1 | Vincere con forza non è il piano. Ma il diavolo riscuote. |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Copia Potere | 2-3 | Firma. Il bonus copia il bonus, il potere copia il potere. Clone totale. |
| Convergente | Copia POT/DAN | 1-2 | Varianti della copia. |
| Convergente | Blocca Potere | 2 | L'altra faccia: se non puoi copiare, neutralizzi. |
| Convergente | Blocca Bonus | 1 | Neutralizzazione bonus nemico. |
| Convergente | -POT nem. | 2 | Indebolisci il nemico. Complementare alla copia. |
| Asso | +POT/+DAN propri | 2-3 | Forza non parassitaria. Il diavolo che non ha bisogno di patti. |
| Asso | DAN dir. | 1-2 | Danno diretto. Smette di giocare e colpisce. |

**Eccezione:** +POT + Imboscata è doppiamente asso (trigger asso + effetto asso). -POT nem. + Intervento è ultra-convergente.

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Intervento + Copia Potere | Convergente pieno | IL cuore della Corte. Giochi seconda, diventi il nemico. |
| Intervento + Blocca Potere | Convergente pieno | L'altra faccia. Se non puoi copiare, cancelli. |
| Intervento + -POT nem. | Convergente pieno | Il sabotatore. |
| Intervento + Copia DAN | Convergente pieno | Rubi la capacità offensiva del nemico. |
| Resa dei conti + Copia Potere | Convergente pieno | Parassita late game con informazione completa. |
| Resa dei conti + -VA nem. | Convergente pieno | Controllo late game. |
| Sempre + Blocca Bonus | Convergente pieno | Neutralizzi il bonus nemico permanentemente, il tuo bonus copia il suo. Asimmetria. |
| Imboscata + +POT | Doppiamente asso | Il diavolo che smette di manipolare e attacca. Rara ma devastante. |
| Imboscata + Copia POT | Ibrido | Trigger asso, effetto convergente. Meno info ma copi comunque. |
| Vendetta + DAN dir. | Asso | Il diavolo ferito si vendica con danno diretto. |
| Conquista + DAN dir. | Asso | Vinci e aggiungi danno. Il patto riscosso. |

### Identità

Specchio deformante. Il nucleo (Intervento + Copia/Blocca) reagisce e si adatta. Non ha identità propria — l'identità È quella del nemico, rubata o cancellata. Le carte asso sono i momenti dove il diavolo mostra la sua vera natura: forza propria, violenza diretta. Tensione: "copio il nemico o lo distruggo con le mie mani?"

---

## 🔮 CIRCOLO MISTICO

**Bonus:** +1 DAN [Sempre]

### Gameplan

"L'armata dei mille volti." Bonus generico sempre attivo, nessun playstyle forzato. L'identità del Circolo È non avere un trigger dominante. Nel Circolo tutte le carte sono un po' asso (nessuna sinergia esplosiva col bonus) ma tutte funzionano decentemente. Nessun ceiling esplosivo, nessun floor terribile.

### Trigger

Nessun trigger supera x3. Obiettivo: coprire tutti o quasi i trigger del gioco. Nessun'altra armata fa questo.

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Neutro | Resa dei conti | 2-3 | L'armata versatile che migliora con più informazione. |
| Neutro | Sempre | 2 | Coerenza col bonus Sempre. |
| Neutro | Conquista | 2 | Opportunismo. |
| Neutro | Intervento | 2 | Un tocco di Corte. |
| Vario | Gloria, Imboscata, Vendetta, Overdrive, Rimonta, Magnanimo, Ultimo Desiderio | 1 ciascuno | Una carta per ogni "sapore". Il Circolo prende in prestito un pezzo di ogni armata. |

### Effetti

Nessun effetto supera x2-3. Mix di tutto.

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Morbidamente conv. | +POT | 2-3 | Buff generico. |
| Morbidamente conv. | -VA nem. | 1-2 | Controllo. |
| Morbidamente conv. | +FC | 1-2 | Risorse. |
| Morbidamente conv. | Copia POT/DAN | 1-2 | Adattamento. |
| Morbidamente asso | Immune | 1 | Troppo specializzato per armata versatile. |
| Morbidamente asso | Effetti estremi (+4 POT) | 1 | All-in, rinuncia alla versatilità. |
| Vario | Blocca Potere, Blocca Bonus, DAN dir., Cura, +DAN | 1 ciascuno | Un po' di tutto. |

### Combinazioni Chiave

Il Circolo non ha combinazioni "firma". Ha combinazioni **uniche** — pezzi presi in prestito da ogni armata.

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Overdrive + effetto forte su corpo debole | Tipo-Calibri | L'Arcimago. Il mago che va all-in. Unica carta che richiede investimento grosso. |
| Rimonta + +POT alto | Tipo-Progenie | La Fenice. Un turno sotto PV è fortissima. |
| Magnanimo + +POT | Tipo-opposta | La Scintilla. Quando stai vincendo, esplodi. Contrario della Fenice. |
| Sempre + -VA nem. forte | Tipo-Comete | Controllo costante. |
| Conquista + +FC | Tipo-Enclave | Economia opportunistica. |
| Intervento + Copia POT | Tipo-Corte | Adattamento reattivo. |
| Vendetta + +POT | Tipo-Progenie | Recupero dopo sconfitta. |
| Gloria + +POT/+DAN | Tipo-Enclave | Momentum. |

### Identità

L'armata che prende in prestito un pezzo di ogni altra armata senza eccellere in nessuna. Ha una carta tipo-Calibri, una tipo-Progenie, una tipo-Corte, una tipo-Enclave. Nessuna è forte quanto l'originale, ma averle tutte dà flessibilità unica. Tensione: non tra due stati, ma tra dieci possibilità. Ogni turno scegli quale armata imitare.

---

## 🐛 SCIAME DIVORANTE

**Bonus:** Imboscata: +1 POT, +1 DAN

### Gameplan

"Evoluzione adattiva." L'armata con più carte asso. Ogni carta è una scelta: primo per il bonus, secondo per il potere. Non raggiungi mai il massimo ma hai sempre un'opzione.

Due gameplan dallo stesso mazzo:
- **Gameplan A (blitz):** Imboscata + buff, colpisci primo, domina. Le carte Intervento sono asso.
- **Gameplan B (kamikaze):** Auto-danno, Rimonta, Vendetta, sopravvivi e contrattacca. Le carte Imboscata diventano asso, i trigger "perdente" diventano convergenti.

La stessa carta è convergente in un gameplan e asso nell'altro. L'evoluzione come metafora meccanica.

### Trigger

Rapporto asso/convergenti più alto di tutte le armate: quasi 50/50.

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Imboscata | 3-4 | Potere + bonus = ceiling massimo. Il Predatore Alfa: quando tutto si allinea. |
| Convergente | Conquista | 2 | Aggressione pura. Vinci giocando primo. |
| Asso | Intervento | 3-4 | Il cuore asso dello Sciame. Potere forte ma rinunci al bonus +1/+1. La scelta. |
| Asso | Vendetta | 2 | Perdi un turno → valore. Ponte verso gameplan B. |
| Asso | Rimonta | 1-2 | Sotto PV. Core del gameplan B kamikaze. |
| Neutro | Sempre | 1 | Presenza costante. |
| Neutro | Resa dei conti | 1 | L'organismo che evolve nel late game. |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | +POT/+DAN | 3-4 | Si stackano col bonus +1/+1 su Imboscata. |
| Convergente | DAN dir. | 2-3 | Aggressione pura, danno immediato. |
| Convergente | -PV a te | 1-2 | Auto-danno per abilitare gameplan B (Rimonta). |
| Asso | Copia POT | 1-2 | Parassitismo. Forte ma sovrascrive POT invece di sommarsi al bonus. |
| Asso | Blocca Potere | 1 | Controllo. Fuori identità aggressiva. |
| Asso | Cura | 1 | Sopravvivenza. Lo Sciame non si cura, si sacrifica. Eccezione "l'evoluzione trova una via". |
| Asso | -DAN nem. | 1 | Difesa. Aliena all'identità. |
| Asso | -POT nem. | 1 | Debuff. Lo Sciame che avvelena invece di divorare. |

**Eccezione:** -DAN nem. + Rimonta è doppiamente asso (sotto PV + difesa). Abilita gameplan B ma è completamente fuori identità aggressiva.

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Imboscata + +POT/+DAN | Convergente pieno | Si somma al bonus +1/+1. Ceiling massimo. |
| Imboscata + DAN dir. | Convergente pieno | Colpisci per primo, danno diretto. |
| Imboscata + -POT nem. | Trigger conv. + effetto asso | Giochi primo ma debuffi invece di rafforzarti. Lo Sciame che avvelena. |
| Intervento + Copia POT | Asso classico | Giochi seconda, copi la forza. Forte ma mai al massimo. |
| Intervento + +DAN | Asso | Giochi seconda, +2 DAN ma perdi +1/+1 bonus. La scelta: generico o specifico? |
| Intervento + Blocca Potere | Asso | Lo Sciame che reagisce e neutralizza. Fuori identità ma potentissimo. |
| Vendetta + Cura | Asso | Perdi, sopravvivi. Sicurezza per gameplan B. |
| Vendetta + +POT | Asso | Il parassita che evolve dalla sconfitta. |
| Rimonta + -DAN nem. | Doppiamente asso | Sotto PV, riduci danno. Abilita gameplan B kamikaze. |
| Conquista + -PV a te | Convergente + twist | Vinci → bonus attivo, MA auto-danno → abiliti Rimonta. Ponte tra gameplan A e B. |
| Sempre + -DAN nem. | Neutro | Creatura che debuffa passivamente. Corpo solido. |

### Identità

Due facce. Gameplan A (blitz): Imboscata + buff, colpisci primo, domina. Gameplan B (kamikaze): auto-danno, Rimonta, Vendetta, contrattacca. La stessa carta cambia ruolo tra i due piani. Il giocatore sceglie quale faccia mostrare o cambia a metà partita. L'evoluzione.

---

## 🐉 ENCLAVE DELLE SCAGLIE

**Bonus:** Conquista: +2 FC

### Gameplan

"Snowball draconico." Vinci → +2 FC → reinvesti → vinci ancora. L'armata più aggressiva e lineare: colpisci per primo, domina, accumula. Il piano A funziona quasi sempre, il piano B è una tantum.

### Trigger

L'armata più concentrata sui trigger convergenti.

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Imboscata | 4 | Colpisci per primo. |
| Convergente | Gloria | 3 | Momentum dopo vittoria. Snowball. |
| Convergente | Conquista | 2-3 | Sinergia diretta col bonus. |
| Asso | Ultimo Desiderio | 2 | L'Enclave non vuole perdere. Ma il drago morente sputa fuoco. |
| Asso | Vendetta | 1-2 | Perdi un turno → recuperi. Lo snowball si interrompe ma non crolla. |
| Asso | Intervento | 1 | Il guardiano della tana. Reattivo su armata proattiva. |
| Neutro | Sempre | 1 | Il drago che semplicemente è grosso. |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | +FC | 4-5 | Firma. Stacka col bonus. 6 carte dell'armata generano FC. Snowball. |
| Convergente | +POT | 3-4 | Vincere duelli è il prerequisito per Conquista. |
| Convergente | DAN dir. | 2 | Danno aggiuntivo. Accelera chiusura. |
| Asso | Immune | 1 | Difesa passiva su armata proattiva. Il Drago Antico. |
| Asso | Blocca Potere | 1 | Controllo reattivo. |
| Asso | Cura | 1 | Non dovrebbe servire se il piano funziona. Stabilizza se non funziona. |
| Asso | +DAN alto | 1 | Chiusura. |

**Eccezione:** +FC su Ultimo Desiderio è quasi convergente nonostante trigger asso. Perdi ma guadagni FC → lo snowball non si interrompe del tutto. Il trigger è asso ma l'effetto ne mitiga la divergenza.

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Imboscata + +POT | Convergente pieno | Giochi primo, sei più forte, vinci, Conquista +2 FC. Il ciclo base. |
| Gloria + +FC | Convergente pieno | Hai vinto → FC extra. Lo snowball accelera. |
| Gloria + +POT alto | Convergente pieno | Momentum: hai vinto, ora sei ancora più forte. |
| Conquista + DAN dir. | Convergente pieno | Vinci e devasta. Il drago che non si accontenta. |
| Conquista + +FC | Convergente col bonus | Vinci → bonus +2 FC → potere +FC aggiuntivi. Accumulo esplosivo. |
| Imboscata + DAN dir. | Convergente pieno | Fuoco prima che il nemico reagisca. |
| Vendetta + Immune | Asso | Il Drago Antico. Piano storto → drago si sveglia → inattaccabile. Piano B potentissimo. |
| Vendetta + +FC | Asso | Perdi ma recuperi risorse. Lo snowball non crolla. |
| Ultimo Desiderio + +FC | Asso (quasi conv.) | Drago cade ma il tesoro resta. Lo snowball continua. |
| Ultimo Desiderio + DAN dir. | Asso | Drago morente sputa fuoco un'ultima volta. |
| Intervento + Blocca Potere | Asso | Il guardiano della tana. Protegge quando serve. |
| Sempre + corpo alto puro | Neutro | Il drago grosso. Nessun effetto, solo stats. Il bonus +2 FC premia vincere, corpo alto vince. |

### Identità

L'armata più lineare. "Gioca primo, vinci, accumula, ripeti." Le carte asso (Vendetta, Ultimo Desiderio) sono la rete di sicurezza — il drago ferito che non muore facilmente. L'Enclave non si reinventa, persevera.

---

## 🐀 RATTI DELLA MEGERA

**Bonus:** Conquista: Tossina 2 (min 4)

### Gameplan

"Morte lenta." Debuffa il nemico fino a renderlo impotente, poi vinci e applica Tossina. Non uccidi con forza, uccidi col tempo. L'armata del declino inesorabile.

### Trigger

| Tipo | Trigger | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | Intervento | 4 | Vedi il nemico, debuffa di conseguenza. Il veleno mirato. |
| Convergente | Imboscata | 2-3 | Debuffa prima che il nemico reagisca. Il ratto che avvelena prima dell'alba. |
| Convergente | Conquista | 2-3 | Sinergia diretta col bonus Tossina. |
| Asso | Vendetta | 2 | Perdere non è nel piano (devi vincere per Tossina). Ma il ratto che perdi e torna è pericoloso. |
| Asso | Ultimo Desiderio | 2 | Perdi il duello, mordi morendo. Danno residuo. |
| Asso | Gloria | 1 | Raro che i Ratti vincano. Ma se vincono, il turno dopo è ancora peggio per il nemico. Pressione psicologica. |
| Neutro | Sempre | 1 | Presenza costante. La Megera. |

### Effetti

| Tipo | Effetto | Quantità target | Logica |
|------|---------|-----------------|--------|
| Convergente | -POT nem. | 3-4 | Debuff firma. Indebolisci il nemico. |
| Convergente | -DAN nem. | 2 | Altra faccia del debuff. |
| Convergente | -VA nem. | 1-2 | Terza via di debuff. |
| Convergente | Blocca Potere | 1-2 | Neutralizzazione. |
| Convergente | Blocca Bonus | 1 | Neutralizzazione bonus. |
| Convergente | DAN dir. | 1-2 | Il closer che manca ai Ratti. La peste che finalmente uccide. |
| Asso | +POT propria | 1-2 | Il ratto che ha smesso di avvelenare e ha iniziato a mordere. |
| Asso | Tossina aggiuntiva | 1 | Si somma al bonus. Veleno su veleno. |
| Asso | Cura | 1 | Aliena ai Ratti. Il veleno è per gli altri. |

### Combinazioni Chiave

| Combinazione | Tipo | Ruolo |
|---|---|---|
| Intervento + -POT nem. | Convergente pieno | Giochi seconda, vedi il nemico, lo indebolisci. Il veleno mirato. |
| Intervento + Blocca Potere | Convergente pieno | Giochi seconda, neutralizzi il potere. Il nemico è nudo. |
| Intervento + Blocca Bonus | Convergente pieno | Neutralizzi il bonus. Il TUO bonus Tossina resta attivo. |
| Intervento + -DAN nem. | Convergente pieno | Veleno nei muscoli. |
| Imboscata + -POT nem. forte | Convergente pieno | Avveleni prima dell'alba. |
| Imboscata + -VA nem. | Convergente pieno | Debuff VA giocando primo. |
| Conquista + DAN dir. | Convergente pieno | Vinci → Tossina (bonus) + danno diretto. Il closer. |
| Conquista + Tossina aggiuntiva | Ultra-convergente | Vinci → Tossina bonus + Tossina potere. Veleno su veleno. |
| Vendetta + +POT | Asso | Il Ratto Gigante. Perdi, torni enorme. Pressione psicologica: non lasciarlo sopravvivere. |
| Vendetta + -DAN nem. | Trigger asso + effetto conv. | Perdi, avveleni i muscoli per il turno dopo. |
| Ultimo Desiderio + DAN dir. | Asso | Il ratto morde morendo. |
| Gloria + -POT nem. forte | Asso | I Ratti vincono un turno → il nemico è ancora più debole dopo. Non vuoi MAI far vincere i Ratti. |
| Sempre + Blocca Potere | Convergente pieno | La Megera. Nessuna condizione, nessuna via d'uscita. |

### Identità

L'armata del declino inesorabile. Ogni turno il nemico è più debole, più avvelenato, più vicino alla fine. Nucleo: debuff reattivo (Intervento + -POT/-DAN/-VA) che prepara, poi Conquista + DAN dir./Tossina che chiude. Le carte asso creano pressione psicologica: i Ratti sono pericolosi anche quando non dovrebbero esserlo. Tensione per il *nemico*: "ogni turno peggiora per me, ma se provo a chiudere in fretta i Ratti hanno carte asso che mi puniscono."

---

## RIEPILOGO COMPARATIVO

### Distribuzione Trigger Target

| Armata | Convergenti principali | Asso principali | Firma |
|--------|----------------------|-----------------|-------|
| Calibri Pesanti | Overdrive 4-5, Vendetta 2, Ultimo Desiderio 2 | Gloria 2, Magnanimo 1, Imboscata 1-2 | Overdrive |
| Comete | Resa dei conti 3-4, Gloria 2-3, Sempre 2-3 | Imboscata 2, Vendetta 1-2 | Resa dei conti |
| Progenie di Babele | Vendetta 3-4, Ultimo Desiderio 3, Rimonta 2 | Gloria 2-3, Magnanimo 1-2 | Vendetta |
| Corte dei Diavoli | Intervento 4-5, Resa dei conti 2-3 | Imboscata 2, Vendetta 2 | Intervento |
| Circolo Mistico | Nessuno dominante (max x3) | Tutti a x1 | Nessuno (varietà) |
| Sciame Divorante | Imboscata 3-4, Conquista 2 | Intervento 3-4, Vendetta 2, Rimonta 1-2 | Imboscata/Intervento (duale) |
| Enclave delle Scaglie | Imboscata 4, Gloria 3, Conquista 2-3 | Ultimo Desiderio 2, Vendetta 1-2 | Imboscata |
| Ratti della Megera | Intervento 4, Imboscata 2-3, Conquista 2-3 | Vendetta 2, Ultimo Desiderio 2, Gloria 1 | Intervento |

### Distribuzione Effetti Target

| Armata | Effetti convergenti firma | Effetti asso principali |
|--------|--------------------------|------------------------|
| Calibri Pesanti | -DAN nem., Immune, Cura, +FC | +POT, DAN dir. |
| Comete | -VA nem., +FC, Copia POT | DAN dir., +POT/+DAN |
| Progenie di Babele | +POT, -PV a te, DAN dir. | Cura, Immune, +DAN |
| Corte dei Diavoli | Copia (Potere/POT/DAN), Blocca (Potere/Bonus), -POT nem. | +POT/+DAN propri, DAN dir. |
| Circolo Mistico | Mix di tutto (nessuno dominante) | Effetti estremi (Overdrive +4 POT) |
| Sciame Divorante | +POT/+DAN, DAN dir., -PV a te | Copia POT, Blocca Potere, Cura, -DAN/-POT nem. |
| Enclave delle Scaglie | +FC, +POT, DAN dir. | Immune, Blocca Potere, Cura |
| Ratti della Megera | -POT/-DAN/-VA nem., Blocca (Potere/Bonus), DAN dir. | +POT propria, Tossina extra, Cura |

### Rapporto Asso/Convergenti

| Armata | Convergenti | Asso | Neutri | Carattere |
|--------|-------------|------|--------|-----------|
| Enclave | ~65% | ~25% | ~10% | Più lineare |
| Comete | ~60% | ~30% | ~10% | Controllore |
| Calibri | ~60% | ~30% | ~10% | Tattico |
| Ratti | ~60% | ~30% | ~10% | Attrizione |
| Progenie | ~55% | ~35% | ~10% | Comeback |
| Corte | ~55% | ~35% | ~10% | Parassita |
| Sciame | ~40% | ~50% | ~10% | **Più carte asso** |
| Circolo | Distribuzione piatta, nessuna dominanza | | | Versatile |

---

*Framework Identità Armate — SATZE — Febbraio 2026*
