# SATZE - SISTEMA DI BILANCIAMENTO COMPLETO

*Versione 2.0 - Gennaio 2026*

---

## INDICE

1. [Definizioni e Parametri](#definizioni-e-parametri)
2. [UnitÃ  di Misura e Formule](#unitÃ -di-misura-e-formule)
3. [Valori Statistiche](#valori-statistiche)
4. [Trigger Completi](#trigger-completi)
5. [Effetti Completi](#effetti-completi)
6. [Bonus Armata](#bonus-armata)
7. [Soglie e Principi di Design](#soglie-e-principi-di-design)
8. [Guida alla Valutazione](#guida-alla-valutazione)
9. [Esempi Pratici](#esempi-pratici)
10. [Carte da Monitorare](#carte-da-monitorare)

---

## DEFINIZIONI E PARAMETRI

### Terminologia

| Termine | Significato |
|---------|-------------|
| **Valore Effettivo** | Valore medio considerando la probabilitÃ  di attivazione dei trigger |
| **Valore Potenziale** | Valore massimo quando Potere E Bonus Armata sono entrambi attivi |
| **Efficienza (Eff)** | Valore Totale / Lega |
| **Body** | Statistiche base della carta (POT + DAN) |
| **Corpo** | Sinonimo di Body |

> **Importante:** Entrambi i valori (Effettivo e Potenziale) devono essere considerati nella valutazione di una carta. Il valore effettivo indica la performance media, il valore potenziale indica il ceiling della carta.

### Parametri di Gioco

| Risorsa | Valore |
|---------|--------|
| Punti Vita iniziali | 25 PV |
| Focus Coin iniziali | 18 FC |
| Carte per deck | 10 |
| Limite Lega totale | 30 punti |
| Scontri per partita | max 10 |
| Turni per Supremazia | dal turno 5 |

---

## UNITÃ€ DI MISURA E FORMULE

### UnitÃ  Base

Il sistema usa **1 FC come unitÃ  base** di valore.

**Motivazione:** I FC sono la risorsa finita, universale e quantificabile che determina ogni decisione nel gioco.

### Formula Valore Effettivo (medio)

```
Valore Effettivo = Body Base + (Potere Ã— Trigger) + (Bonus Ã— Trigger Bonus)

Dove:
- Body Base = (POT Ã— 0.5) + (DAN Ã— 0.35)
- Potere Ã— Trigger = Valore Effetto Ã— Moltiplicatore Trigger
- Bonus Ã— Trigger Bonus = Valore Bonus Ã— Moltiplicatore Trigger Bonus
```

### Formula Valore Potenziale (massimo)

```
Valore Potenziale = Body Potenziato + Potere + Bonus

Dove:
- Body Potenziato = (POT + mod POT potere + mod POT bonus) Ã— 0.5 + (DAN + mod DAN potere + mod DAN bonus) Ã— 0.35
- Potere = Valore Effetto pieno (trigger = 1.0)
- Bonus = Valore Bonus pieno (trigger = 1.0)
```

### Formula Efficienza

```
Efficienza Effettiva = Valore Effettivo / Lega
Efficienza Potenziale = Valore Potenziale / Lega
```

---

## VALORI STATISTICHE

### Buff (potenziamento proprio)

| Statistica | Valore per punto | Motivazione |
|------------|------------------|-------------|
| **+1 POT** | 0.50 FC | Stat gateway, scala con FC investiti |
| **+1 DAN** | 0.35 FC | Valore per Supremazia, richiede vittoria |
| **+1 VA** | 0.28 FC | Non scala, meno efficiente di POT |
| **+1 FC** | 0.70 FC | Valore differito e condizionato |
| **1 DAN diretto** | 0.50 FC | Garantito, bypassa combattimento |
| **Cura 1 PV** | 0.20 FC | Difensivo, non aiuta a vincere |
| **-1 PV (auto)** | -0.20 FC | Costo puro |

### Debuff (applicati al nemico)

| Effetto | Valore per punto | Note |
|---------|------------------|------|
| **-1 POT nem.** | 0.50 FC | Equivalente a +1 POT |
| **-1 DAN nem.** | 0.35 FC | Equivalente a +1 DAN |
| **-1 VA nem.** | 0.28 FC | Equivalente a +1 VA |

### Effetto "Minimo" (min X)

Gli effetti con minimo hanno efficacia ridotta:

| Minimo | Efficacia stimata | Esempio |
|--------|-------------------|---------|
| min 1-2 | ~80% | -3 POT nem. (min 2) |
| min 3-4 | ~70% | -2 DAN nem. (min 3) |
| min 5-6 | ~55% | -12 VA nem. (min 6) |

**Formula con minimo:**
```
Valore = Valore Base Ã— Efficacia Minimo
```

---

## TRIGGER COMPLETI

### Tabella Riassuntiva

| Trigger | Moltiplicatore | Categoria | Controllo | Finestra |
|---------|----------------|-----------|-----------|----------|
| **Sempre attivo** | 1.0 | â€” | Totale | Sempre |
| **Imboscata** | 0.7 | Posizione | Parziale | Sempre |
| **Intervento** | 0.7 | Posizione | Parziale | Sempre |
| **Gloria** | 0.6 | Esito prec. | Bassa | Sempre |
| **Vendetta** | 0.6 | Esito prec. | Bassa | Sempre |
| **Conquista** | 0.6 | Esito corr. | Media | Sempre |
| **Ultimo Desiderio** | 0.6 | Esito corr. | Media | Sempre |
| **Sfida** | 0.6 | Lega | Totale | Sempre |
| **Sopraffare** | 0.6 | Lega | Totale | Sempre |
| **Resa dei conti** | 0.5 | Temporale | Totale | T3+ |
| **Overdrive** | 0.5 | Risorse | Totale | Sempre |
| **Opportunista** | 0.5 | Risorse | Nessuna | Sempre |
| **Invasione** | 0.5 | Stato campi | Bassa | T2+ |
| **Resistenza** | 0.5 | Stato campi | Nessuna | T2+ |
| **Rimonta** | 0.4 | Stato PV | Bassa | Variabile |
| **Magnanimo** | 0.4 | Stato PV | Bassa | Variabile |
| **Ultima Chance** | 0.4 | Temporale | Totale | T5+ |
| **Turbo** | 0.3 | Temporale | Totale | T1-2 |

---

### Descrizioni Dettagliate

#### CATEGORIA: POSIZIONE

| Trigger | Condizione | Note |
|---------|------------|------|
| **Imboscata** | Sei il primo a scegliere | 50% controllabile, dipende dall'ordine |
| **Intervento** | Sei il secondo a scegliere | 50% controllabile, vedi carta nemica |

#### CATEGORIA: ESITO PRECEDENTE

| Trigger | Condizione | Note |
|---------|------------|------|
| **Gloria** | Hai vinto lo scontro precedente | Non attivo T1 |
| **Vendetta** | Hai perso lo scontro precedente | Non attivo T1 |

#### CATEGORIA: ESITO CORRENTE

| Trigger | Condizione | Note |
|---------|------------|------|
| **Conquista** | Vinci questo scontro | Si risolve dopo il calcolo VA |
| **Ultimo Desiderio** | Perdi questo scontro | Si risolve dopo il calcolo VA |

#### CATEGORIA: LEGA

| Trigger | Condizione | Note |
|---------|------------|------|
| **Sfida** | Tua Lega < Lega nemica | Informazione pubblica, prevedibile |
| **Sopraffare** | Tua Lega > Lega nemica | Informazione pubblica, prevedibile |

**Interazione:** In caso di Lega pari, nÃ© Sfida nÃ© Sopraffare si attivano.

#### CATEGORIA: RISORSE (FC)

| Trigger | Condizione | Note |
|---------|------------|------|
| **Overdrive** | Spendi 5+ FC | Controllabile ma costoso |
| **Opportunista** | Il nemico spende 5+ FC | Non controllabile, counter a Overdrive |

**Momento verifica:** Dopo la rivelazione simultanea dei FC.

#### CATEGORIA: STATO PV

| Trigger | Condizione | Note |
|---------|------------|------|
| **Rimonta** | Hai meno PV del nemico | Verificato prima dello scontro |
| **Magnanimo** | Hai piÃ¹ PV del nemico | Verificato prima dello scontro |

**Interazione:** Se i PV sono pari, nÃ© Rimonta nÃ© Magnanimo si attivano.

#### CATEGORIA: STATO CAMPI

| Trigger | Condizione | Note |
|---------|------------|------|
| **Invasione** | Hai conquistato 1+ campi | Non attivo T1 |
| **Resistenza** | Il nemico ha conquistato 1+ campi | Non attivo T1 |

**Momento verifica:** Inizio turno (prima della scelta carte).

#### CATEGORIA: TEMPORALE

| Trigger | Condizione | Turni attivi |
|---------|------------|--------------|
| **Turbo** | Turno 1 o 2 | Solo T1-T2 |
| **Resa dei conti** | Entrambi hanno giocato 2+ carte | T3+ |
| **Ultima Chance** | Turno 5+ | T5+ |

---

### Logica dei Moltiplicatori

```
MOLTIPLICATORE
    â”‚
1.0 â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆ  Sempre attivo (garantito)
    â”‚
0.7 â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆ        Imboscata, Intervento (50% controllo)
    â”‚
0.6 â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆ              Gloria, Vendetta, Conquista, 
    â”‚                                      Ultimo Desiderio, Sfida, Sopraffare
    â”‚
0.5 â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆ                Resa dei conti, Overdrive,
    â”‚                                      Opportunista, Invasione, Resistenza
    â”‚
0.4 â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆ                      Rimonta, Magnanimo, Ultima Chance
    â”‚
0.3 â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆ                        Turbo (finestra strettissima)
```

---

## EFFETTI COMPLETI

### Effetti Speciali (valore fisso)

| Effetto | Valore FC | Tipo | Note |
|---------|-----------|------|------|
| **Immune** | 2.00 | Difensivo | Ignora debuff POT/DAN/VA |
| **Copia Potere** | 1.50 | Adattivo | Scala con forza avversario |
| **Blocca Potere** | 1.50 | Controllo | Neutralizza carte abilitÃ -dipendenti |
| **Copia POT** | 1.50 | Adattivo | Copia POT base nemica |
| **Inversione** | 1.00 | Conversione | Converte debuff in buff (e viceversa) |
| **Copia DAN** | 1.00 | Adattivo | Copia DAN base nemica |
| **Blocca Bonus** | 1.00 | Controllo | Neutralizza Bonus Armata nemico |
| **Copia Bonus** | 0.80 | Adattivo | Copia Bonus Armata nemico |

---

### Effetti Scaling (valore variabile)

#### ESCALATION

> **Escalation X [STAT]:** +X [STAT] per ogni campo che hai conquistato.

| Campi | Escalation 1 | Escalation 2 |
|-------|--------------|--------------|
| 0 | +0 | +0 |
| 1 | +1 | +2 |
| 2 | +2 | +4 |

**Valori FC:**

| Effetto | Calcolo | Valore medio |
|---------|---------|--------------|
| Escalation 1 POT | 0.50 Ã— 1.3 (campi medi) | ~0.65 FC |
| Escalation 2 POT | 1.00 Ã— 1.3 | ~1.30 FC |
| Escalation 1 DAN | 0.35 Ã— 1.3 | ~0.45 FC |
| Escalation 2 DAN | 0.70 Ã— 1.3 | ~0.90 FC |

**Note:**
- Nessun cap massimo
- PuÃ² applicarsi a piÃ¹ stat: "Escalation 1 POT, 1 DAN"
- Effetto snowball: premia chi sta vincendo

---

#### ATTRIZIONE

> **Attrizione X [STAT]:** +X [STAT] per ogni carta che hai giÃ  giocato.

| Carte giocate | Turno tipico | Attrizione 1 | Attrizione 2 |
|---------------|--------------|--------------|--------------|
| 0 | T1 | +0 | +0 |
| 1 | T2 | +1 | +2 |
| 2 | T3 | +2 | +4 |
| 3 | T4 | +3 | +6 |
| 4 | T5 | +4 | +8 |

**Valori FC:**

| Effetto | Calcolo | Valore medio |
|---------|---------|--------------|
| Attrizione 1 POT | 0.50 Ã— 2 (carte medie) | ~1.00 FC |
| Attrizione 2 POT | 1.00 Ã— 2 | ~2.00 FC |
| Attrizione 1 DAN | 0.35 Ã— 2 | ~0.70 FC |
| Attrizione 2 DAN | 0.70 Ã— 2 | ~1.40 FC |

**Note:**
- Conta SOLO le tue carte giocate
- Cresce naturalmente durante la partita
- âš ï¸ Attrizione 2 puÃ² diventare molto forte (cap implicito consigliato)

---

#### INVERSIONE

> **Inversione:** I modificatori esterni (da nemico e campo) sono invertiti.

**Cosa viene invertito:**
- âœ“ Debuff nemici (-X POT/DAN/VA â†’ +X)
- âœ“ Buff da campi (+X â†’ -X)
- âœ“ Debuff da campi (-X â†’ +X)

**Cosa NON viene invertito:**
- âœ— Il proprio Potere
- âœ— Il proprio Bonus Armata
- âœ— Danni diretti
- âœ— Blocca Potere/Blocca Bonus

**Valore:** ~1.00 FC (alta varianza, dipende dal matchup)

| Scenario | Valore reale |
|----------|--------------|
| vs Deck debuff-heavy (Ratti) | ~2.5 FC |
| vs Deck misto | ~1.0 FC |
| vs Deck senza debuff | ~0 FC |

---

### Tabella Riepilogativa Effetti

| Tipo | Effetto | Valore FC | VariabilitÃ  |
|------|---------|-----------|-------------|
| **Buff fisso** | +1 POT | 0.50 | Nessuna |
| **Buff fisso** | +1 DAN | 0.35 | Nessuna |
| **Buff fisso** | +1 VA | 0.28 | Nessuna |
| **Buff fisso** | +1 FC | 0.70 | Nessuna |
| **Debuff fisso** | -1 POT nem. | 0.50 | Nessuna |
| **Debuff fisso** | -1 DAN nem. | 0.35 | Nessuna |
| **Debuff fisso** | -1 VA nem. | 0.28 | Nessuna |
| **Danno** | 1 DAN dir. | 0.50 | Nessuna |
| **Cura** | Cura 1 | 0.20 | Nessuna |
| **Costo** | -1 PV (auto) | -0.20 | Nessuna |
| **Speciale** | Immune | 2.00 | Bassa |
| **Speciale** | Copia Potere | 1.50 | Alta (dipende da nemico) |
| **Speciale** | Blocca Potere | 1.50 | Media |
| **Speciale** | Copia POT | 1.50 | Alta |
| **Speciale** | Copia DAN | 1.00 | Alta |
| **Speciale** | Blocca Bonus | 1.00 | Media |
| **Speciale** | Copia Bonus | 0.80 | Alta |
| **Conversione** | Inversione | 1.00 | Molto alta |
| **Scaling** | Escalation 1 POT | 0.65 | Media (campi) |
| **Scaling** | Escalation 1 DAN | 0.45 | Media (campi) |
| **Scaling** | Attrizione 1 POT | 1.00 | Media (turni) |
| **Scaling** | Attrizione 1 DAN | 0.70 | Media (turni) |

---

## BONUS ARMATA

### Tabella Completa

| Armata | Bonus | Trigger | Valore Eff | Valore Pot | Modifica Stats |
|--------|-------|---------|------------|------------|----------------|
| **Corte** | Copia Bonus nem. | Sempre | 0.80 | 0.80 | â€” |
| **Comete** | -5 VA nem. (min 6) | Sempre | 0.77 | 0.77 | â€” |
| **Legione** | -2 DAN nem. (min 2) | Sempre | 0.70 | 0.70 | â€” |
| **Sciame** | +1 POT, +1 DAN | Imboscata | 0.59 | 0.85 | +1/+1 |
| **Progenie** | +2 POT | Rimonta | 0.40 | 1.00 | +2/+0 |
| **Circolo** | +1 DAN | Sempre | 0.35 | 0.35 | +0/+1 |
| **Enclave** | +2 FC | Conquista | 0.84 | 1.40 | â€” |
| **Ratti** | Tossina 2 (min 4) | Conquista | 0.42 | 0.70 | â€” |

> **Nota:** I bonus che modificano le stats proprie (Progenie, Sciame, Circolo) aumentano il Body Potenziato nel calcolo del Valore Potenziale.

### Calcolo con Bonus Armata

Per attivare il Bonus Armata servono **2+ carte della stessa armata** nel deck.

```
Valore con Bonus = Valore Base + (Bonus Ã— Moltiplicatore Trigger Bonus)
```

---

## SOGLIE E PRINCIPI DI DESIGN

### Soglie Corpo (POT + DAN rispetto alla Lega)

| Categoria | Formula | Lega 2 | Lega 3 | Lega 4 | Lega 5 |
|-----------|---------|--------|--------|--------|--------|
| **Mediocre** | â‰¤ LegaÃ—2 - 1 | â‰¤3 | â‰¤5 | â‰¤7 | â‰¤9 |
| **Buona** | = LegaÃ—2 | 4 | 6 | 8 | 10 |
| **Forte** | â‰¥ LegaÃ—2 + 1 | â‰¥5 | â‰¥7 | â‰¥9 | â‰¥11 |

### Soglie Assolute

| Stat | Mediocre | Buono | Forte | Eccezionale |
|------|----------|-------|-------|-------------|
| **Potenza** | 1-2 | 3-4 | 5-6 | 7+ |
| **Danno** | 1-2 | 3 | 4-5 | 6+ |

### Equilibrio Stats

| Tipo | Differenza POT-DAN |
|------|-------------------|
| **Equilibrata** | â‰¤ 2 |
| **Sbilanciata** | â‰¥ 3 |

### Principi di Design

1. **Corpo mediocre â†’ PuÃ² avere abilitÃ  potente**
2. **Corpo forte â†’ AbilitÃ  debole o assente**
3. **Auto-danno = Costo** (non valore strategico nel calcolo)
4. **Carte flagship Lega 5 = Intenzionalmente sopra curva**
5. **Considerare sempre il potenziale con Bonus Armata attivo**
6. **POT Ã¨ la stat "gateway"** â€” serve per vincere, vale piÃ¹ di DAN

### Limiti Consigliati per Nuovi Effetti

| Effetto | Limite | Motivo |
|---------|--------|--------|
| Escalation POT | Max 2 | Evita snowball eccessivo |
| Escalation DAN | Max 1 | DAN scala pericolosamente |
| Attrizione POT | Max 2 | Late game giÃ  forte |
| Attrizione DAN | Max 1 | +4 DAN a T5 Ã¨ giÃ  molto |
| Inversione | 1-2 carte totali | Counter troppo hard ai debuff |

---

## GUIDA ALLA VALUTAZIONE

### Step 1: Calcola il Body Base

```
Body Base = (POT Ã— 0.5) + (DAN Ã— 0.35)
```

**Esempio:** POT 4, DAN 3
```
Body = (4 Ã— 0.5) + (3 Ã— 0.35) = 2.0 + 1.05 = 3.05 FC
```

### Step 2: Valuta il Potere

1. Determina il **valore dell'effetto** (dalla tabella effetti)
2. Moltiplica per il **moltiplicatore del trigger**

```
Valore Potere = Valore Effetto Ã— Moltiplicatore Trigger
```

**Esempio:** "+2 POT" con trigger "Vendetta"
```
Valore = (2 Ã— 0.5) Ã— 0.6 = 1.0 Ã— 0.6 = 0.6 FC
```

### Step 3: Aggiungi il Bonus Armata (se applicabile)

```
Valore Bonus = Valore Bonus Armata Ã— Moltiplicatore Trigger Bonus
```

**Esempio:** Bonus Sciame (+1 POT, +1 DAN con Imboscata)
```
Valore = (0.5 + 0.35) Ã— 0.7 = 0.85 Ã— 0.7 = 0.59 FC
```

### Step 4: Calcola il Valore Totale

```
Valore Effettivo = Body + Potere + Bonus
Efficienza = Valore Effettivo / Lega
```

### Step 5: Calcola il Valore Potenziale

Ripeti i calcoli assumendo che **tutti i trigger siano attivi** (moltiplicatore = 1.0).

Per effetti che modificano stats, calcola il **Body Potenziato**:
```
Body Potenziato = (POT + mod POT) Ã— 0.5 + (DAN + mod DAN) Ã— 0.35
```

### Step 6: Confronta con le Medie

| Lega | Eff. Media | Eff. Buona | Eff. Alta |
|------|------------|------------|-----------|
| 2 | 1.4-1.6 | 1.6-1.8 | 1.8+ |
| 3 | 1.3-1.5 | 1.5-1.7 | 1.7+ |
| 4 | 1.1-1.3 | 1.3-1.5 | 1.5+ |
| 5 | 1.0-1.2 | 1.2-1.4 | 1.4+ |

---

## ESEMPI PRATICI

### Esempio 1: Carta Semplice

```
SENTINELLA ASTRALE
Lega: 2 | POT: 3 | DAN: 1
Potere: Vendetta: +3 POT
Armata: Comete

CALCOLO EFFETTIVO:
- Body: (3 Ã— 0.5) + (1 Ã— 0.35) = 1.85 FC
- Potere: (3 Ã— 0.5) Ã— 0.6 = 0.9 FC
- Bonus Comete: 0.77 FC
- Totale: 1.85 + 0.9 + 0.77 = 3.52 FC
- Efficienza: 3.52 / 2 = 1.76

CALCOLO POTENZIALE:
- Body Potenziato: (6 Ã— 0.5) + (1 Ã— 0.35) = 3.35 FC
- Potere (trigger=1): 1.5 FC
- Bonus: 0.77 FC
- Totale: 3.35 + 1.5 + 0.77 = 5.62 FC
- Efficienza: 5.62 / 2 = 2.81

VALUTAZIONE: Alta varianza (1.76 â†’ 2.81). Forte se Vendetta attivo.
```

---

### Esempio 2: Carta con Effetto Scaling

```
VETERANO DI MILLE BATTAGLIE (ipotetica)
Lega: 4 | POT: 4 | DAN: 3
Potere: Attrizione 1 DAN
Armata: Legione

CALCOLO EFFETTIVO:
- Body: (4 Ã— 0.5) + (3 Ã— 0.35) = 3.05 FC
- Potere: 0.70 FC (Attrizione 1 DAN, media)
- Bonus Legione: 0.70 FC
- Totale: 3.05 + 0.70 + 0.70 = 4.45 FC
- Efficienza: 4.45 / 4 = 1.11

CALCOLO POTENZIALE (T5, 4 carte giocate):
- Body Potenziato: (4 Ã— 0.5) + (7 Ã— 0.35) = 4.45 FC
- Potere: 1.40 FC (4 Ã— 0.35)
- Bonus: 0.70 FC
- Totale: 4.45 + 1.40 + 0.70 = 6.55 FC
- Efficienza: 6.55 / 4 = 1.64

VALUTAZIONE: Efficienza media ma scaling pericoloso. DAN 7 al T5 Ã¨ devastante.
```

---

### Esempio 3: Carta con Nuovo Trigger

```
SFIDANTE TEMERARIO (ipotetica)
Lega: 2 | POT: 3 | DAN: 2
Potere: Sfida: +2 POT
Armata: Progenie

CALCOLO EFFETTIVO:
- Body: (3 Ã— 0.5) + (2 Ã— 0.35) = 2.2 FC
- Potere: (2 Ã— 0.5) Ã— 0.6 = 0.6 FC
- Bonus Progenie: 0.40 FC
- Totale: 2.2 + 0.6 + 0.40 = 3.2 FC
- Efficienza: 3.2 / 2 = 1.60

CALCOLO POTENZIALE (vs Lega 5, Rimonta attivo):
- Body Potenziato: (7 Ã— 0.5) + (2 Ã— 0.35) = 4.2 FC
- Potere: 1.0 FC
- Bonus: 1.0 FC
- Totale: 4.2 + 1.0 + 1.0 = 6.2 FC
- Efficienza: 6.2 / 2 = 3.10

VALUTAZIONE: Bilanciato in media, esplosivo contro Lega alte + Rimonta.
```

---

### Esempio 4: Carta con Inversione

```
SPECCHIO MALEDETTO (ipotetica)
Lega: 3 | POT: 3 | DAN: 2
Potere: Inversione
Armata: Ratti

CALCOLO EFFETTIVO:
- Body: (3 Ã— 0.5) + (2 Ã— 0.35) = 2.2 FC
- Potere: 1.0 FC (Inversione, stima media)
- Bonus Ratti: 0.42 FC
- Totale: 2.2 + 1.0 + 0.42 = 3.62 FC
- Efficienza: 3.62 / 3 = 1.21

VALUTAZIONE: Sotto la media per Lega 3. Ma:
- vs Ratti nemici: Inversione vale ~2.5 FC â†’ Efficienza ~1.70
- vs Circolo: Inversione vale ~0 FC â†’ Efficienza ~0.87

Alta varianza dipendente dal matchup. Carta di nicchia.
```

---

### Esempio 5: Carta con Turbo

```
BERSERKER DELL'ALBA (ipotetica)
Lega: 2 | POT: 3 | DAN: 2
Potere: Turbo: -3 PV (a te)
Armata: Progenie

CALCOLO EFFETTIVO (considerando che T3+ il malus non si attiva):
- Body: (3 Ã— 0.5) + (2 Ã— 0.35) = 2.2 FC
- Potere: (-3 Ã— 0.2) Ã— 0.3 = -0.18 FC
- Bonus Progenie: 0.40 FC
- Totale: 2.2 - 0.18 + 0.40 = 2.42 FC
- Efficienza: 2.42 / 2 = 1.21

VALUTAZIONE: 
- T1-2: Corpo 3/2 con -3 PV = aggressivo ma costoso
- T3+: Corpo 3/2 senza malus = solido per Lega 2

Il design Ã¨ intenzionale: puoi scegliere quando subire il malus.
```

---

## CARTE DA MONITORARE

### Alto Potenziale, Bassa Efficienza (dipendono dal trigger)

| Carta | Armata | Lega | Eff | Pot | Note |
|-------|--------|------|-----|-----|------|
| Seguace Fanatico | Progenie | 2 | 1.43 | **2.92** | Gloria +4 POT + Rimonta |
| Sentinella Astrale | Comete | 2 | 1.76 | **2.81** | Vendetta +3 POT |
| Scintilla Primordiale | Circolo | 2 | 1.25 | **2.62** | Magnanimo +3 POT + bonus |

### Alta Efficienza, Basso Delta (sempre forti)

| Carta | Armata | Lega | Eff | Pot | Note |
|-------|--------|------|-----|-----|------|
| Diavoletto Ingannatore | Corte | 2 | **2.02** | 2.67 | Imboscata +2 POT |
| Titano Corazzato MK-IV | Legione | 5 | **1.56** | 1.56 | Immune sempre |
| Zarkon | Comete | 5 | **1.48** | 1.48 | -8 VA sempre |

### Combinazioni da Monitorare (Nuove Meccaniche)

| Combinazione | Rischio | Note |
|--------------|---------|------|
| Sfida + effetto forte (Lega 2) | Alto | Efficienza esplosiva vs Lega 5 |
| Invasione + Escalation | Alto | Doppio snowball |
| Attrizione 2 + Ultima Chance | Alto | +8 stat garantito T5+ |
| Turbo + corpo forte | Medio | Nessun downside dopo T2 |
| Inversione vs Ratti | Medio | Counter troppo hard? |

---

## EFFETTI NON CATTURATI DAL SISTEMA

1. **Valore del bluff** â€” Overdrive crea incertezza tattica
2. **Sinergie con Bonus Armata** â€” Es. Nimrod 9/5 con Rimonta attivo
3. **Combo tra carte** â€” Es. auto-danno per attivare Rimonta
4. **Meta-game** â€” Alcune carte valgono piÃ¹ contro certi matchup
5. **Informazione pubblica** â€” Sfida/Sopraffare sono prevedibili
6. **Timing forzato** â€” Turbo costringe a giocare presto
7. **Pressione psicologica** â€” Ultima Chance incentiva a chiudere prima del T5
8. **Varianza di Inversione** â€” Dipende completamente dal matchup

---

## CHECKLIST VALUTAZIONE RAPIDA

```
â–¡ Body nella norma per la Lega? (Lega Ã— 2)
â–¡ POT â‰¥ 3? (stat gateway)
â–¡ Potere ha valore proporzionato al trigger?
â–¡ Efficienza Effettiva nella media? (vedi tabella)
â–¡ Delta Eff/Pot ragionevole? (< 1.0 idealmente)
â–¡ Sinergia con Bonus Armata?
â–¡ Interazioni problematiche con altri effetti?
â–¡ Considerati gli effetti non numerici?
```

---

*Sistema di Bilanciamento Completo - Versione 2.0 - Gennaio 2026*
