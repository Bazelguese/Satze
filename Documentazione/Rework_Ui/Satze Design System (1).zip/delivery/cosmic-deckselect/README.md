# 📦 Pacchetto Cosmic — DeckSelect ("Scelta Mazzo Pre-Duello")

## CONTENUTO
- `DeckSelectCosmic.jsx` — componente React completo (556 righe). Layout: header con "DUELLO IMMINENTE" + avversario, carosello mazzi al centro (3 visibili, centrale ingrandito + frecce + dots), pannello dettagli a destra con stats POT/DAN/CARTE/WIN-RATE, curva lega, trigger principali, pulsanti ANTEPRIMA/MODIFICA, footer marquee animato. Stile cosmic identico al builder.
- `cosmic-tokens.css` — token CSS globali.

## INTEGRAZIONE IN `Codice/satze.jsx`

### Step 1 — Copia file
```
src/components/cosmic/DeckSelectCosmic.jsx
src/styles/cosmic-tokens.css   (se non già presente)
```

### Step 2 — Sostituisci il rendering della fase `selectDeck`

In `Codice/satze.jsx` trova il blocco che renderizza la fase di scelta mazzo pre-duello (`gamePhase === 'selectDeck'`).

**Wrappa** in un container fixed full-screen con sfondo opaco:

```jsx
import DeckSelectCosmic from '../src/components/cosmic/DeckSelectCosmic.jsx';

{gamePhase === 'selectDeck' && (
  <div style={{ position: 'fixed', inset: 0, zIndex: 50, background: '#06030a' }}>
    <DeckSelectCosmic
      decks={availableDecks}
      selectedArmy={selectedArmy}
      opponent={opponentInfo}
      onSelectDeck={(deck) => {
        setSelectedDeck(deck);
        setGamePhase('selectDifficulty');  // o 'selectField' a seconda del flow
      }}
      onBack={() => setGamePhase('selectArmy')}
      onEditDeck={(deckId) => {
        setEditingDeckId(deckId);
        setShowDeckManager(true);
        setDeckManagerView('edit');
        setDeckManagerSource('selectDeck');
      }}
    />
  </div>
)}
```

### Step 3 — Sostituisci dati demo con dati reali

Il componente usa **dati demo hardcoded** (righe 14-22). Sostituiscili:
- `decks` → array di mazzi salvati per l'armata scelta, da `loadCustomDecks().filter(d => d.army === selectedArmy)`
- Per ogni mazzo calcola: `cards` (numero carte), `lega` (lega totale), `pot` (POT medio), `dan` (DAN medio), `win` (win-rate da statistiche, o 0 se mancante), `lead` (path immagine carta leader del mazzo)
- `cur.warning` → se mazzo incompleto (`cards < 30` o `lega > 30`), passa stringa tipo `"2 carte mancanti"` per mostrare il banner rosso
- Pulsante `SCHIERA MAZZO ›` → chiama `onSelectDeck(decks[active])`
- Pulsante `← INDIETRO` → chiama `onBack()`
- Pulsante `✎ MODIFICA` → chiama `onEditDeck(decks[active].id)`

### Step 4 — IMPORTANTE: nascondi il menu

Stesso fix del builder — assicurati che `<SatzeMenuPrototype/>` venga renderizzato solo se `gamePhase === 'menu'` e nessun overlay è aperto.

## VINCOLI
- NON cambiare la logica di selezione armata/mazzo/difficoltà
- NON rimuovere `selectedArmy` o `selectedDeck` dallo state
- Il pulsante `SCHIERA MAZZO ›` deve essere disabilitato se `cur.warning` (già gestito nel componente)
- Mantenere il flow `selectArmy → selectDeck → selectDifficulty → selectField → battle`

## NOTE STILE
Il componente ha già:
- Sfondo opaco con radial gradient + halftone pattern
- Background giant text "SCHIERA" decorativo
- Corner brackets magenta agli angoli
- Footer marquee animato con `@keyframes data-marquee`
- Animazione `pulse-glow` sul badge "● SELEZIONATO"

Tutte le animazioni richiedono che `cosmic-transitions.css` (o equivalente con i keyframes `pulse-glow` e `data-marquee`) sia importato. Se non c'è già, aggiungi questi keyframes a `cosmic-tokens.css`:

```css
@keyframes pulse-glow { 0%,100% { filter: drop-shadow(0 0 8px currentColor) } 50% { filter: drop-shadow(0 0 18px currentColor) } }
@keyframes data-marquee { from { transform: translateX(0) } to { transform: translateX(-50%) } }
```
