# 📦 Pacchetto Cosmic — DeckBuilder ("Costruzione Esercito")

## CONTENUTO
- `DeckBuilderCosmic.jsx` — componente React completo (601 righe). Layout: header con logo SATZE + stats LEGA/CARTE, griglia carte a sinistra con filtri faction/lega/sort, pannello mazzo a destra con stats POT MED/DAN MED, bonus attivi, lista carte, pulsante CONFERMA MAZZO. Stile cosmic: nero `#06030a`, magenta `#c026d3`, pink heat `#ec4899`, viola `#a78bfa`, font Cinzel + Chakra Petch + Share Tech Mono.
- `cosmic-tokens.css` — token CSS globali (font import, palette, spacing).

## INTEGRAZIONE IN `Codice/satze.jsx`

### Step 1 — Copia file
```
src/components/cosmic/DeckBuilderCosmic.jsx
src/styles/cosmic-tokens.css   (se non già presente)
```

### Step 2 — Importa una volta `cosmic-tokens.css` in `src/main.jsx`
```js
import './styles/cosmic-tokens.css';
```

### Step 3 — Sostituisci il rendering builder esistente

In `Codice/satze.jsx` trova il blocco che renderizza `<SatzeDeckBuilderPrototype/>` quando `deckManagerView === 'edit'` (o quando si modifica un mazzo). 

**Wrappa** il builder cosmic in un wrapper che:
1. Si monta a tutto schermo (`position: fixed; inset: 0`)
2. Ha sfondo opaco (`background: #06030a`)
3. Ha z-index alto (≥50) per coprire il menu
4. Riceve gli stessi handler/state del builder vecchio

Esempio:
```jsx
import DeckBuilderCosmic from '../src/components/cosmic/DeckBuilderCosmic.jsx';

// Dentro il rendering di SatzeGame:
{showDeckManager && deckManagerView === 'edit' && (
  <div style={{ position: 'fixed', inset: 0, zIndex: 50, background: '#06030a' }}>
    <DeckBuilderCosmic
      deck={editingDeck}
      onSaveDeck={handleSaveDeck}
      onClose={() => setDeckManagerView('list')}
      // ...altri handler esistenti
    />
  </div>
)}
```

### Step 4 — Sostituisci dati demo con dati reali

Il componente ora usa **dati demo hardcoded** (vedi righe 28-50). Sostituiscili con:
- `cards` → carte filtrate da `ARMY_DECKS[army]` o `resolveDeckCardsForArmy(army)`
- `deck` → stato corrente del mazzo in editing (`editingDeck` o equivalente)
- Click `+`/`−` su `<CardRow>` → handler `addCardToDeck` / `removeCardFromDeck`
- `onClick` di `CONFERMA MAZZO ›` → `onSaveDeck`
- `onClick` di `← CHIUDI` → `onClose`

### Step 5 — IMPORTANTE: nascondi il menu quando il builder è aperto

Trova dove viene renderizzato `<SatzeMenuPrototype/>` (o il menu cosmic) e aggiungi:
```jsx
{gamePhase === 'menu' && !showDeckManager && (
  <SatzeMenuPrototype .../>
)}
```

Senza questo fix, il menu trasparirà sotto il builder.

## VINCOLI
- NON modificare la logica di salvataggio mazzi
- NON cambiare i nomi degli state esistenti
- Mantenere compatibilità con `deckManagerSource` per il "Indietro" corretto
