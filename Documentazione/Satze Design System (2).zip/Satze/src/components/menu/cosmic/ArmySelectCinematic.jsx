// ============================================
// ArmySelectCinematic — Schermata "Scegli la tua armata"
// ============================================
// Drop-in: usa i dati REALI del progetto (ARMY_SETS, ARMY_BONUSES,
// ARMY_COLORS, ARMY_ICONS, ARMY_GIFS) e un file di lore separato
// (./armyLore.js) che è l'UNICA cosa che il giocatore/designer deve
// modificare.
//
// Props:
//   onSelect(armyName: string)  — chiamato dopo l'animazione di conferma
//   onBack()                    — torna al menu precedente
//
// Logica preservata: questa è SOLO la presentazione visiva. Il
// chiamante decide cosa fare con `armyName` (di solito apre la scelta
// dell'esercito/deck).
// ============================================

import { useState, useEffect, useMemo } from 'react';
import {
  ARMY_COLORS,
  ARMY_BONUSES,
  ARMY_GIFS,
  ARMY_ICONS,
} from '../../../data/armies.js';
import { ARMY_SETS, ARMY_DECKS } from '../../../data/cards.js';
import { ARMY_LORE, MIXED_ARMIES_LORE } from './armyLore.js';

const STAT_LABELS = {
  aggressione: 'Aggressione',
  difesa: 'Difesa',
  tempo: 'Tempo',
  difficolta: 'Difficoltà',
};

// Costruisce la lista armate dal data layer reale.
// "Eserciti misti" è una entry sintetica (multi-armata), mostrata per prima.
function buildArmies() {
  const list = [];

  // 1) Multi-armata
  list.push({
    id: 'mixed',
    name: 'Eserciti Misti',
    sub: 'ESERCITI MULTI-ARMATA',
    color: '#a78bfa',
    portrait: null,
    bg: null,
    glyph: '⚔',
    cards: 0,
    decks: 0,
    bonus: null,
    bonusLabel: 'NESSUNO',
    lore: MIXED_ARMIES_LORE.lore,
    style: MIXED_ARMIES_LORE.style,
    keywords: MIXED_ARMIES_LORE.keywords,
    stats: MIXED_ARMIES_LORE.stats,
    isMixed: true,
  });

  // 2) Armate canoniche, in ordine ARMY_SETS
  for (const armyName of Object.keys(ARMY_SETS)) {
    const lore = ARMY_LORE[armyName] || {};
    const cards = ARMY_SETS[armyName] || [];
    const decks = ARMY_DECKS?.[armyName] ? Object.keys(ARMY_DECKS[armyName]).length : 2;
    const colors = ARMY_COLORS[armyName] || { accent: '#94a3b8' };
    const bonus = ARMY_BONUSES[armyName];

    list.push({
      id: armyName,
      name: armyName,
      sub: lore.sub || `${cards.length} CARTE • ${decks} ESERCITI`,
      color: colors.accent,
      portrait: ARMY_ICONS[armyName] || null,
      bg: ARMY_GIFS[armyName] || null,
      glyph: lore.glyph || '◈',
      cards: cards.length,
      decks,
      bonus: bonus?.description || '—',
      bonusLabel: lore.bonusLabel || (bonus?.trigger ? bonus.trigger.toUpperCase() : 'PASSIVO'),
      lore: lore.lore || '',
      style: lore.style || '',
      keywords: lore.keywords || [],
      stats: lore.stats || null,
      isMixed: false,
    });
  }

  return list;
}

// ============================================
// COMPONENTE PRINCIPALE
// ============================================

export default function ArmySelectCinematic({ onSelect, onBack }) {
  const ARMIES = useMemo(() => buildArmies(), []);
  const [idx, setIdx] = useState(1); // parte dalla prima armata vera, non multi
  const [prevIdx, setPrevIdx] = useState(1);
  const [phase, setPhase] = useState('intro'); // intro -> idle -> confirming
  const [pulse, setPulse] = useState(0);
  const [cursor, setCursor] = useState({ x: 0.5, y: 0.5 });

  const total = ARMIES.length;
  const army = ARMIES[idx];

  useEffect(() => {
    const t = setTimeout(() => setPhase('idle'), 1700);
    return () => clearTimeout(t);
  }, []);

  const go = (delta) => {
    setPrevIdx(idx);
    setIdx((idx + delta + total) % total);
    setPulse((p) => p + 1);
  };
  const goTo = (i) => {
    if (i === idx) return;
    setPrevIdx(idx);
    setIdx(i);
    setPulse((p) => p + 1);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (phase !== 'idle') return;
      if (e.key === 'ArrowLeft') go(-1);
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'Enter') confirmArmy();
      if (e.key === 'Escape' && onBack) onBack();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  useEffect(() => {
    const onMove = (e) => {
      const w = window.innerWidth, h = window.innerHeight;
      setCursor({ x: e.clientX / w, y: e.clientY / h });
    };
    window.addEventListener('mousemove', onMove);
    return () => window.removeEventListener('mousemove', onMove);
  }, []);

  const confirmArmy = () => {
    if (phase !== 'idle') return;
    setPhase('confirming');
    setTimeout(() => {
      onSelect && onSelect(army.isMixed ? null : army.name);
    }, 1500);
  };

  const px = (cursor.x - 0.5) * 2;
  const py = (cursor.y - 0.5) * 2;

  return (
    <div className={`asc phase-${phase}`} style={{ '--accent': army.color }}>
      <BgLayer prev={ARMIES[prevIdx]} cur={army} px={px} py={py} pulse={pulse}/>

      <header className="asc-top">
        <button className="asc-back" onClick={onBack}>
          <span className="ar">←</span><span className="lbl">MENU</span>
        </button>
        <div className="asc-title-block">
          <div className="asc-eyebrow" style={{ color: army.color }}>FASE I · SCHIERAMENTO</div>
          <h1 className="asc-title">SCEGLI LA TUA ARMATA</h1>
        </div>
        <div/>
      </header>
      <div className="asc-sub" style={{ '--accent': army.color }}>
        Seleziona il set con cui vuoi combattere — premi <kbd>↵</kbd> per schierare
      </div>

      <div className="asc-stage">
        <NavArrow side="left" onClick={() => go(-1)} accent={army.color}/>
        <div className="asc-track">
          {[-2, -1, 0, 1, 2].map((off) => {
            const i = (idx + off + total) % total;
            const a = ARMIES[i];
            return (
              <CarouselCard
                key={`${i}-${off}`}
                army={a}
                offset={off}
                isCenter={off === 0}
                pulse={pulse}
                px={px} py={py}
                onClick={() => off !== 0 && goTo(i)}
              />
            );
          })}
        </div>
        <NavArrow side="right" onClick={() => go(1)} accent={army.color}/>
      </div>

      <DetailPanel army={army} key={`d-${idx}`} onConfirm={confirmArmy}/>

      <div className="asc-ticker">
        {ARMIES.map((a, i) => (
          <button
            key={a.id}
            className={`asc-tk ${i === idx ? 'on' : ''}`}
            onClick={() => goTo(i)}
            style={{ '--c': a.color }}
          >
            <span className="num">{String(i+1).padStart(2,'0')}</span>
            <span className="nm">{a.name}</span>
          </button>
        ))}
      </div>

      {phase === 'intro' && <SigilloIntro accent={army.color} glyph={army.glyph}/>}
      {phase === 'confirming' && <ConfirmTransition army={army}/>}
      <div className="asc-scan"/>

      <ArmySelectStyles/>
    </div>
  );
}

// ============================================
// Sub-componenti
// ============================================

function BgLayer({ prev, cur, px, py, pulse }) {
  return (
    <div className="asc-bg-layer">
      <div
        key={`prev-${pulse}`}
        className="asc-bg prev"
        style={{
          backgroundImage: prev.bg ? `url('${prev.bg}')` : undefined,
          transform: `translate(${px*12}px, ${py*8}px) scale(1.1)`,
        }}
      />
      <div
        key={`cur-${pulse}`}
        className="asc-bg cur"
        style={{
          backgroundImage: cur.bg ? `url('${cur.bg}')` : undefined,
          transform: `translate(${px*18}px, ${py*12}px) scale(1.06)`,
        }}
      >
        {!cur.bg && <div className="asc-bg-fallback" style={{ '--accent': cur.color }}>{cur.glyph}</div>}
      </div>
      <div className="asc-bg-vignette"/>
      <div className="asc-stars"/>
    </div>
  );
}

function NavArrow({ side, onClick, accent }) {
  return (
    <button className={`asc-arrow ${side}`} onClick={onClick} style={{ '--accent': accent }} aria-label={side}>
      <svg viewBox="0 0 56 56" width="56" height="56">
        <polygon
          points={side === 'left' ? '38,12 18,28 38,44' : '18,12 38,28 18,44'}
          fill="none" stroke="currentColor" strokeWidth="2"
        />
        <circle cx="28" cy="28" r="26" fill="none" stroke="currentColor" strokeOpacity="0.3" strokeWidth="1"/>
      </svg>
    </button>
  );
}

function CarouselCard({ army, offset, isCenter, pulse, px, py, onClick }) {
  const tx = isCenter ? px * 14 : 0;
  const ty = isCenter ? py * 8 : 0;
  return (
    <div
      className={`asc-cc ${isCenter ? 'is-center' : ''}`}
      style={{
        '--accent': army.color,
        '--off': offset,
        zIndex: 10 - Math.abs(offset),
        '--tx': `${tx}px`,
        '--ty': `${ty}px`,
      }}
      onClick={onClick}
    >
      <div className="asc-cc-bg" style={{ backgroundImage: army.bg ? `url('${army.bg}')` : 'none' }}>
        {!army.bg && <div className="asc-cc-bg-fb" style={{ '--accent': army.color }}>{army.glyph}</div>}
      </div>
      <div className="asc-cc-vignette"/>
      {isCenter && <SigilloRing accent={army.color}/>}
      <div className="asc-cc-portrait" key={`p-${pulse}`}>
        {army.portrait
          ? <img src={army.portrait} alt={army.name} draggable={false}/>
          : <div className="asc-cc-glyph" style={{ color: army.color }}>{army.glyph}</div>}
      </div>
      {isCenter && <div className="asc-cc-scan"/>}
      <div className="asc-cc-name" style={{ color: army.color }}>{army.name}</div>
      {isCenter && <div className="asc-cc-corners"><span/><span/><span/><span/></div>}
    </div>
  );
}

function SigilloRing({ accent }) {
  return (
    <svg className="asc-cc-sigillo" viewBox="0 0 400 400" width="100%" height="100%">
      <g className="asc-cc-sigillo-spin">
        <circle cx="200" cy="200" r="160" fill="none" stroke={accent} strokeOpacity="0.5" strokeWidth="0.5" strokeDasharray="3 8"/>
        <circle cx="200" cy="200" r="140" fill="none" stroke={accent} strokeOpacity="0.18" strokeWidth="1"/>
        <circle cx="200" cy="200" r="120" fill="none" stroke={accent} strokeOpacity="0.4" strokeWidth="0.4" strokeDasharray="1 5"/>
        {Array.from({length: 12}).map((_, i) => {
          const a = (i / 12) * Math.PI * 2;
          const x = 200 + Math.cos(a) * 150;
          const y = 200 + Math.sin(a) * 150;
          const ch = ['◇','▲','✦','▽','✧','◈','✕','✺','◬','◉','✚','☩'][i];
          return <text key={i} x={x} y={y} fill={accent} fillOpacity="0.55" fontFamily="monospace" fontSize="10" textAnchor="middle" dominantBaseline="middle">{ch}</text>;
        })}
      </g>
    </svg>
  );
}

function StatBar({ label, value, accent }) {
  return (
    <div className="asc-stat">
      <div className="asc-stat-head">
        <span className="lbl">{label}</span>
        <span className="val" style={{ color: accent }}>{value}</span>
      </div>
      <div className="asc-stat-track">
        <div className="asc-stat-fill" style={{ width: `${value}%`, background: `linear-gradient(90deg, ${accent}40, ${accent})`, boxShadow: `0 0 8px ${accent}80` }}/>
      </div>
    </div>
  );
}

function DetailPanel({ army, onConfirm }) {
  return (
    <>
      <aside className="asc-side asc-side-l" style={{ '--accent': army.color }}>
        <div className="asc-side-inner">
          <div className="asc-side-eye">{army.sub}</div>
          <h2 className="asc-side-name">{army.name}</h2>
          {army.lore && <p className="asc-side-lore">"{army.lore}"</p>}
          {army.style && (
            <div className="asc-side-style">
              <div className="lbl">STILE DI GIOCO</div>
              <div className="txt">{army.style}</div>
            </div>
          )}
          {army.keywords?.length > 0 && (
            <div className="asc-side-tags">
              {army.keywords.map((k) => (
                <span key={k} style={{ borderColor: `${army.color}66`, color: army.color }}>{k}</span>
              ))}
            </div>
          )}
        </div>
      </aside>

      <aside className="asc-side asc-side-r" style={{ '--accent': army.color }}>
        <div className="asc-side-inner">
          <div className="asc-bonus" style={{ borderColor: army.color }}>
            <div className="asc-bonus-eye" style={{ color: army.color }}>BONUS · {army.bonusLabel}</div>
            <div className="asc-bonus-val">{army.bonus || '— Multi-Armata —'}</div>
            <div className="asc-bonus-foot">
              <span><b>{army.cards || '—'}</b> Carte</span>
              <span className="dot">•</span>
              <span><b>{army.decks || '—'}</b> Eserciti</span>
            </div>
          </div>
          {army.stats && (
            <div className="asc-stats">
              <div className="asc-stats-head">PROFILO TATTICO</div>
              {Object.entries(army.stats).map(([k, v]) => (
                <StatBar key={k} label={STAT_LABELS[k] || k} value={v} accent={army.color}/>
              ))}
            </div>
          )}
          <button className="asc-confirm" style={{ borderColor: army.color, color: army.color }} onClick={onConfirm}>
            <span className="bg"/>
            <span className="lbl">SCHIERA</span>
            <span className="arr">→</span>
            <span className="key">↵</span>
          </button>
        </div>
      </aside>
    </>
  );
}

function SigilloIntro({ accent, glyph }) {
  return (
    <div className="asc-intro" style={{ '--accent': accent }}>
      <svg viewBox="0 0 800 800" width="800" height="800" className="asc-intro-svg">
        <defs>
          <radialGradient id="ascigrad">
            <stop offset="0%" stopColor={accent} stopOpacity="0.3"/>
            <stop offset="100%" stopColor={accent} stopOpacity="0"/>
          </radialGradient>
        </defs>
        <circle cx="400" cy="400" r="380" fill="url(#ascigrad)"/>
        <g className="asc-intro-spin">
          <circle cx="400" cy="400" r="320" fill="none" stroke={accent} strokeOpacity="0.6" strokeWidth="1" strokeDasharray="2 6"/>
        </g>
      </svg>
      <div className="asc-intro-glyph" style={{ color: accent }}>{glyph}</div>
      <div className="asc-intro-text">APERTURA · SCHIERAMENTO</div>
    </div>
  );
}

function ConfirmTransition({ army }) {
  return (
    <div className="asc-confirming" style={{ '--accent': army.color }}>
      <div className="asc-confirming-flash"/>
      <div className="asc-confirming-iris"/>
      <div className="asc-confirming-text">
        <div className="eye" style={{ color: army.color }}>SIGILLO IMPRESSO</div>
        <div className="nm">{army.name}</div>
        <div className="next">Apertura → Scelta dell'esercito</div>
      </div>
    </div>
  );
}

// ============================================
// STILI (scoped tramite prefisso .asc)
// ============================================

function ArmySelectStyles() {
  return (
    <style>{`
      .asc {
        position: fixed; inset: 0; z-index: 1000;
        background: #050608;
        color: #e8e8ec;
        font-family: 'Chakra Petch', sans-serif;
        overflow: hidden;
      }
      .asc-bg-layer { position: absolute; inset: 0; z-index: 0; }
      .asc-bg {
        position: absolute; inset: -4%;
        background-size: cover; background-position: center;
        filter: brightness(0.42) saturate(1.15);
        transition: opacity .9s, transform 1.2s cubic-bezier(.2,.7,.2,1);
      }
      .asc-bg.cur { opacity: 1; animation: asc-bg-in 1.2s cubic-bezier(.2,.7,.2,1); }
      .asc-bg.prev { opacity: 0; }
      @keyframes asc-bg-in {
        from { opacity: 0; filter: brightness(0.1) blur(8px); }
        to { opacity: 1; }
      }
      .asc-bg-fallback {
        position: absolute; inset: 0;
        display: grid; place-items: center;
        font-family: 'Cinzel', serif; font-size: 600px;
        color: color-mix(in srgb, var(--accent) 25%, transparent);
        text-shadow: 0 0 80px var(--accent);
      }
      .asc-bg-vignette {
        position: absolute; inset: 0;
        background:
          radial-gradient(ellipse at 50% 50%, transparent 25%, rgba(0,0,0,0.75) 85%),
          linear-gradient(to bottom, rgba(0,0,0,0.55) 0%, transparent 28%, transparent 60%, rgba(0,0,0,0.92) 100%);
      }
      .asc-stars {
        position: absolute; inset: 0;
        background-image:
          radial-gradient(1px 1px at 18% 22%, #fff, transparent 100%),
          radial-gradient(1.5px 1.5px at 88% 38%, #fff, transparent 100%),
          radial-gradient(1px 1px at 12% 78%, rgba(255,255,255,0.5), transparent 100%);
        opacity: 0.65;
      }

      .asc-top {
        position: absolute; top: 32px; left: 64px; right: 64px;
        z-index: 10;
        display: grid; grid-template-columns: 200px 1fr 200px;
        align-items: start; gap: 32px;
      }
      .asc-back {
        display: inline-flex; align-items: center; gap: 12px;
        background: rgba(0,0,0,0.5);
        border: 1px solid rgba(255,255,255,0.18);
        color: #e8e8ec;
        font-family: inherit; font-size: 12px; letter-spacing: 0.28em;
        text-transform: uppercase; padding: 12px 18px; cursor: pointer;
        transition: all .2s; backdrop-filter: blur(6px);
      }
      .asc-back:hover { border-color: var(--accent); color: var(--accent); }
      .asc-title-block { text-align: center; }
      .asc-eyebrow {
        font-family: 'Share Tech Mono', monospace;
        font-size: 12px; letter-spacing: 0.4em;
      }
      .asc-title {
        font-family: 'Cinzel', serif; font-weight: 700;
        font-size: 44px; letter-spacing: 0.3em; margin: 6px 0 0;
        text-shadow: 0 4px 24px rgba(0,0,0,0.9);
      }
      .asc-sub {
        position: absolute; left: 50%; top: 130px;
        transform: translateX(-50%); z-index: 9;
        font-family: 'Share Tech Mono', monospace;
        font-size: 12px; letter-spacing: 0.22em;
        color: rgba(255,255,255,0.65); text-transform: uppercase;
      }
      .asc-sub kbd {
        display: inline-block; padding: 1px 6px;
        border: 1px solid color-mix(in srgb, var(--accent) 60%, rgba(255,255,255,0.3));
        margin: 0 2px; color: var(--accent);
        font-family: inherit;
      }

      .asc-stage {
        position: absolute; top: 180px; left: 0; right: 0; bottom: 220px;
        z-index: 5; display: grid;
        grid-template-columns: 80px 1fr 80px;
        align-items: center;
      }
      .asc-track {
        position: relative; height: 100%;
        display: flex; align-items: center; justify-content: center;
        perspective: 1400px;
      }
      .asc-arrow {
        background: transparent; border: 0; cursor: pointer;
        color: rgba(255,255,255,0.5); transition: color .2s, transform .2s;
        display: grid; place-items: center;
      }
      .asc-arrow:hover { color: var(--accent); transform: scale(1.12); }

      .asc-cc {
        position: absolute;
        width: 380px; height: 480px;
        transition: transform .7s cubic-bezier(.2,.7,.2,1), opacity .7s, filter .7s;
        cursor: pointer;
        transform: translate3d(calc(var(--off) * 320px + var(--tx, 0px)), var(--ty, 0px), 0)
                   rotateY(calc(var(--off) * -22deg))
                   scale(calc(1 - abs(var(--off)) * 0.18));
        opacity: calc(1 - abs(var(--off)) * 0.35);
        filter: brightness(calc(1 - abs(var(--off)) * 0.3));
        transform-style: preserve-3d;
      }
      .asc-cc.is-center {
        cursor: default; opacity: 1; filter: brightness(1);
      }
      .asc-cc-bg {
        position: absolute; inset: 0;
        background-size: cover; background-position: center;
        background-color: #0a0a10;
      }
      .asc-cc-bg-fb {
        position: absolute; inset: 0;
        display: grid; place-items: center;
        background: radial-gradient(circle at 50% 50%, color-mix(in srgb, var(--accent) 30%, transparent), transparent 60%);
        font-family: 'Cinzel', serif; font-size: 240px;
        color: var(--accent); text-shadow: 0 0 60px var(--accent);
      }
      .asc-cc-vignette {
        position: absolute; inset: 0;
        background:
          radial-gradient(ellipse at 50% 30%, transparent 30%, rgba(0,0,0,0.85) 100%),
          linear-gradient(to top, rgba(0,0,0,0.95) 0%, transparent 50%);
      }
      .asc-cc-sigillo {
        position: absolute; inset: 0; pointer-events: none;
        opacity: 0.6;
      }
      .asc-cc-sigillo-spin {
        animation: asc-spin 60s linear infinite;
        transform-origin: 200px 200px;
      }
      @keyframes asc-spin { to { transform: rotate(360deg); } }
      .asc-cc-portrait {
        position: absolute; top: 50%; left: 50%;
        transform: translate(-50%, -54%);
        width: 240px; height: 240px;
        display: grid; place-items: center;
        animation: asc-portrait-in .9s cubic-bezier(.2,.7,.2,1);
      }
      @keyframes asc-portrait-in {
        from { opacity: 0; transform: translate(-50%, -54%) scale(0.7); }
        to { opacity: 1; }
      }
      .asc-cc-portrait img {
        width: 100%; height: 100%; object-fit: contain;
        filter: drop-shadow(0 12px 28px rgba(0,0,0,0.85));
      }
      .asc-cc-glyph {
        font-family: 'Cinzel', serif; font-size: 180px;
        text-shadow: 0 0 60px currentColor;
      }
      .asc-cc-scan {
        position: absolute; inset: 0; pointer-events: none;
        background: linear-gradient(180deg, transparent 30%, color-mix(in srgb, var(--accent) 20%, transparent) 50%, transparent 70%);
        background-size: 100% 8px;
        opacity: 0.4;
        animation: asc-scan 3s linear infinite;
      }
      @keyframes asc-scan { to { background-position: 0 -200px; } }
      .asc-cc-name {
        position: absolute; bottom: 24px; left: 0; right: 0;
        text-align: center;
        font-family: 'Cinzel', serif; font-weight: 700;
        font-size: 20px; letter-spacing: 0.22em;
        text-transform: uppercase;
        text-shadow: 0 4px 16px rgba(0,0,0,0.95);
      }
      .asc-cc-corners span {
        position: absolute; width: 18px; height: 18px;
        border-color: var(--accent); border-style: solid; border-width: 0;
      }
      .asc-cc-corners span:nth-child(1) { top: 8px; left: 8px; border-top-width: 2px; border-left-width: 2px; }
      .asc-cc-corners span:nth-child(2) { top: 8px; right: 8px; border-top-width: 2px; border-right-width: 2px; }
      .asc-cc-corners span:nth-child(3) { bottom: 8px; left: 8px; border-bottom-width: 2px; border-left-width: 2px; }
      .asc-cc-corners span:nth-child(4) { bottom: 8px; right: 8px; border-bottom-width: 2px; border-right-width: 2px; }

      .asc-side {
        position: absolute; top: 200px; bottom: 240px;
        width: 320px; z-index: 8;
        display: flex; align-items: center;
      }
      .asc-side-l { left: 32px; }
      .asc-side-r { right: 32px; }
      .asc-side-inner {
        background: rgba(8,9,12,0.78);
        border: 1px solid rgba(255,255,255,0.1);
        border-left: 2px solid var(--accent);
        padding: 22px 22px;
        backdrop-filter: blur(10px);
        width: 100%;
        animation: asc-side-in .6s ease;
      }
      .asc-side-r .asc-side-inner { border-left: 1px solid rgba(255,255,255,0.1); border-right: 2px solid var(--accent); }
      @keyframes asc-side-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; } }
      .asc-side-eye {
        font-family: 'Share Tech Mono', monospace;
        font-size: 10px; letter-spacing: 0.32em;
        color: rgba(255,255,255,0.5); text-transform: uppercase;
      }
      .asc-side-name {
        font-family: 'Cinzel', serif; font-weight: 700;
        font-size: 22px; letter-spacing: 0.12em;
        text-transform: uppercase; margin: 4px 0 12px;
        color: var(--accent);
      }
      .asc-side-lore {
        font-family: 'Cinzel', serif; font-style: italic;
        font-size: 13px; line-height: 1.55;
        color: #cbd5e1; margin: 0 0 14px;
      }
      .asc-side-style { margin-bottom: 14px; }
      .asc-side-style .lbl {
        font-family: 'Share Tech Mono', monospace;
        font-size: 10px; letter-spacing: 0.28em;
        color: rgba(255,255,255,0.5); text-transform: uppercase;
        margin-bottom: 4px;
      }
      .asc-side-style .txt { font-size: 12.5px; line-height: 1.55; color: #d4d4d8; }
      .asc-side-tags { display: flex; flex-wrap: wrap; gap: 6px; }
      .asc-side-tags span {
        font-family: 'Share Tech Mono', monospace;
        font-size: 10px; letter-spacing: 0.22em;
        padding: 4px 10px; border: 1px solid;
        text-transform: uppercase;
      }

      .asc-bonus {
        padding: 14px 18px;
        background: rgba(0,0,0,0.55);
        border: 1px solid; margin-bottom: 12px;
      }
      .asc-bonus-eye {
        font-family: 'Share Tech Mono', monospace;
        font-size: 10px; letter-spacing: 0.28em; text-transform: uppercase;
      }
      .asc-bonus-val {
        font-family: 'Share Tech Mono', monospace;
        font-size: 16px; margin: 6px 0 8px;
      }
      .asc-bonus-foot {
        display: flex; gap: 10px;
        font-family: 'Share Tech Mono', monospace;
        font-size: 11px; color: rgba(255,255,255,0.6);
        letter-spacing: 0.18em;
      }
      .asc-bonus-foot b { color: #e8e8ec; font-weight: 600; }
      .asc-bonus-foot .dot { color: rgba(255,255,255,0.3); }

      .asc-stats-head {
        font-family: 'Share Tech Mono', monospace;
        font-size: 10px; letter-spacing: 0.3em;
        color: rgba(255,255,255,0.55); margin-bottom: 8px;
        text-transform: uppercase;
      }
      .asc-stat { margin-bottom: 7px; }
      .asc-stat-head {
        display: flex; justify-content: space-between;
        font-family: 'Share Tech Mono', monospace;
        font-size: 10px; letter-spacing: 0.18em;
        margin-bottom: 3px;
      }
      .asc-stat-head .lbl { color: rgba(255,255,255,0.7); text-transform: uppercase; }
      .asc-stat-track {
        position: relative; height: 6px;
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.08);
      }
      .asc-stat-fill { height: 100%; transition: width .8s cubic-bezier(.2,.7,.2,1); }

      .asc-confirm {
        position: relative; display: grid;
        grid-template-columns: 1fr auto auto;
        align-items: center; gap: 16px;
        padding: 14px 18px; margin-top: 14px;
        background: rgba(0,0,0,0.6);
        border: 1.5px solid;
        font-family: 'Cinzel', serif; font-weight: 700;
        font-size: 14px; letter-spacing: 0.22em;
        text-transform: uppercase; cursor: pointer;
        transition: all .25s; overflow: hidden; width: 100%;
      }
      .asc-confirm:hover {
        box-shadow: 0 0 30px color-mix(in srgb, var(--accent) 50%, transparent);
        background: rgba(0,0,0,0.8);
      }
      .asc-confirm .arr { font-size: 20px; }
      .asc-confirm .key {
        font-family: 'Share Tech Mono', monospace;
        font-size: 11px; padding: 2px 8px;
        border: 1px solid currentColor; opacity: 0.7;
      }

      .asc-ticker {
        position: absolute; bottom: 36px; left: 50%;
        transform: translateX(-50%); z-index: 9;
        display: flex; gap: 6px; padding: 8px 12px;
        background: rgba(0,0,0,0.45);
        backdrop-filter: blur(6px);
        border: 1px solid rgba(255,255,255,0.08);
        max-width: 90vw; flex-wrap: wrap; justify-content: center;
      }
      .asc-tk {
        background: transparent; border: 1px solid transparent;
        cursor: pointer; padding: 8px 12px;
        opacity: 0.5; display: flex; align-items: center; gap: 8px;
        font-family: 'Share Tech Mono', monospace;
        color: rgba(255,255,255,0.75); transition: all .2s;
      }
      .asc-tk .num { font-size: 10px; opacity: 0.6; letter-spacing: 0.2em; }
      .asc-tk .nm { font-size: 11px; letter-spacing: 0.16em; text-transform: uppercase; }
      .asc-tk:hover { opacity: 0.9; }
      .asc-tk.on {
        opacity: 1; border-color: var(--c);
        background: color-mix(in srgb, var(--c) 14%, transparent);
        color: var(--c);
        box-shadow: 0 0 14px color-mix(in srgb, var(--c) 40%, transparent);
      }

      .asc-intro {
        position: absolute; inset: 0; z-index: 50;
        display: grid; place-items: center;
        background: radial-gradient(circle at 50% 50%, rgba(0,0,0,0.4), rgba(0,0,0,0.95) 80%);
        animation: asc-intro-fade 1.7s ease forwards;
      }
      @keyframes asc-intro-fade {
        0%, 80% { opacity: 1; }
        100% { opacity: 0; pointer-events: none; }
      }
      .asc-intro-svg { position: absolute; animation: asc-intro-zoom 1.7s; }
      @keyframes asc-intro-zoom {
        0% { transform: scale(0.2); opacity: 0; }
        40% { opacity: 1; }
        100% { transform: scale(1.3); opacity: 0; }
      }
      .asc-intro-spin { animation: asc-spin 6s linear infinite; transform-origin: 400px 400px; }
      .asc-intro-glyph {
        position: relative;
        font-family: 'Cinzel', serif; font-size: 200px;
        text-shadow: 0 0 80px currentColor;
        animation: asc-intro-glyph 1.7s ease;
      }
      @keyframes asc-intro-glyph {
        0% { opacity: 0; transform: scale(0.4); }
        50% { opacity: 1; transform: scale(1); }
        100% { opacity: 0; transform: scale(1.6); filter: blur(20px); }
      }
      .asc-intro-text {
        position: absolute; bottom: 28%;
        font-family: 'Share Tech Mono', monospace;
        font-size: 14px; letter-spacing: 0.5em;
        color: rgba(255,255,255,0.85);
        animation: asc-intro-text 1.7s ease;
      }
      @keyframes asc-intro-text {
        0%, 30% { opacity: 0; }
        50% { opacity: 1; }
        100% { opacity: 0; }
      }

      .asc-confirming { position: absolute; inset: 0; z-index: 60; }
      .asc-confirming-flash {
        position: absolute; inset: 0; background: var(--accent);
        animation: asc-cf-flash 1.5s ease; mix-blend-mode: screen; opacity: 0;
      }
      @keyframes asc-cf-flash {
        0% { opacity: 0; } 20% { opacity: 0.5; } 100% { opacity: 0; }
      }
      .asc-confirming-iris {
        position: absolute; inset: 0; background: rgba(0,0,0,0.95);
        clip-path: circle(120% at 50% 50%);
        animation: asc-cf-iris 1.5s cubic-bezier(.7,.05,.3,1) forwards;
      }
      @keyframes asc-cf-iris {
        0% { clip-path: circle(120% at 50% 50%); }
        100% { clip-path: circle(0% at 50% 50%); }
      }
      .asc-confirming-text {
        position: absolute; inset: 0;
        display: grid; place-items: center; align-content: center;
        text-align: center;
        animation: asc-cf-text 1.5s ease;
      }
      @keyframes asc-cf-text {
        0%, 30% { opacity: 0; transform: translateY(20px); }
        60% { opacity: 1; transform: translateY(0); }
        100% { opacity: 0; transform: translateY(-10px); }
      }
      .asc-confirming-text .eye {
        font-family: 'Share Tech Mono', monospace;
        font-size: 12px; letter-spacing: 0.5em; margin-bottom: 12px;
      }
      .asc-confirming-text .nm {
        font-family: 'Cinzel', serif; font-weight: 700;
        font-size: 56px; letter-spacing: 0.18em;
        text-transform: uppercase;
        text-shadow: 0 0 40px var(--accent);
      }
      .asc-confirming-text .next {
        margin-top: 14px;
        font-family: 'Share Tech Mono', monospace;
        font-size: 12px; letter-spacing: 0.32em;
        color: rgba(255,255,255,0.7);
      }

      .asc-scan {
        position: absolute; inset: 0; pointer-events: none; z-index: 90;
        background: repeating-linear-gradient(
          to bottom,
          transparent 0, transparent 3px,
          rgba(255,255,255,0.022) 3px, rgba(255,255,255,0.022) 4px
        );
        mix-blend-mode: overlay;
      }
    `}</style>
  );
}
